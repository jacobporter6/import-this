﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
GO 

/*
███████╗ ██████╗ ██████╗ ████████╗                                  
██╔════╝██╔═══██╗██╔══██╗╚══██╔══╝                                  
███████╗██║   ██║██████╔╝   ██║                                     
╚════██║██║   ██║██╔══██╗   ██║                                     
███████║╚██████╔╝██║  ██║   ██║                                     
╚══════╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝                                     
                                                                    
██████╗ ██████╗  ██████╗ ██████╗ ██╗     ███████╗███╗   ███╗███████╗
██╔══██╗██╔══██╗██╔═══██╗██╔══██╗██║     ██╔════╝████╗ ████║██╔════╝
██████╔╝██████╔╝██║   ██║██████╔╝██║     █████╗  ██╔████╔██║███████╗
██╔═══╝ ██╔══██╗██║   ██║██╔══██╗██║     ██╔══╝  ██║╚██╔╝██║╚════██║
██║     ██║  ██║╚██████╔╝██████╔╝███████╗███████╗██║ ╚═╝ ██║███████║
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝╚═╝     ╚═╝╚══════╝
*/



/*
Turn on query plans!
*/













/*

If I run this, there's one Sort
* The query asks for ~160MB of memory for it
* No index to support my order by...
* Id is only an integer

*/
    
SELECT 
    u.*
FROM 
(  
   SELECT TOP (1000) 
       u.Id 
   FROM dbo.Users AS u
   ORDER BY u.Reputation
) AS u
OPTION(MAXDOP 1);

















/*

If I run this query, there are two Sorts
But the memory grant is about the same 

It goes up a little for the Hash Join
The blocking operation during the Hash Join 
(build probe) allows them to share memory

*/
SELECT 
    *
FROM 
(  
   SELECT TOP (1000) 
       u.Id
   FROM dbo.Users AS u
   ORDER BY u.Reputation
) AS u
JOIN 
(
   SELECT TOP (1000) 
       u.Id
   FROM dbo.Users AS u
   ORDER BY u.Reputation
) AS u2
    ON u.Id = u2.Id
OPTION(MAXDOP 1);











/*

If we force a Nested Loop Join, the memory grant doubles
With no blocking operator, grants can't be shared

Nested loops doesn't block anything, it just starts
looking for rows on the inner side as soon as they arrive

*/
    SELECT 
        *
    FROM 
    (  
       SELECT TOP (1000) 
           u.Id
       FROM dbo.Users AS u
       ORDER BY u.Reputation
    ) AS u
    INNER LOOP JOIN /* Force the loop join */
    ( 
       SELECT TOP (1000) 
           u.Id
       FROM dbo.Users AS u
       ORDER BY u.Reputation
    ) AS u2
        ON u.Id = u2.Id
    OPTION(MAXDOP 1);











/*

If I run this, there's still only one Sort,
but as we add columns, the memory grant gets larger

Optimizer makes a fuzzy guess for string columns:     
  * They'll be half full.
  * Or half empty.
  * Depends on how you look at it.

Hover over the arrow going into the Sort for details about data size.

*/

SELECT 
    u.*
FROM 
(  
   SELECT TOP (1000) 
         u.Id          -- 166MB (INT)
       , u.DisplayName -- 300MB (NVARCHAR 40)
       , u.WebsiteUrl  -- 900MB (NVARCHAR 200)
       , u.Location    -- 1.2GB (NVARCHAR 100)
       , u.AboutMe     -- 13GB (NVARCHAR MAX)
   FROM dbo.Users AS u
   ORDER BY u.Reputation
) AS u
OPTION(MAXDOP 1);













/*

Memory Grants aren't Grant * DOP
* They're Grant / DOP
* Each thread gets an equal share
* Memory grants are decided for a serial plan
* Parallelism is a later exploration stage

*/
    SELECT 
        *
    FROM 
    (  
       SELECT TOP (1000) 
           u.Id
       FROM dbo.Users AS u
       ORDER BY u.Reputation
    ) AS u
    INNER HASH JOIN 
    (
       SELECT TOP (1000) 
           u.Id
       FROM dbo.Users AS u
       ORDER BY u.Reputation
    ) AS u2
        ON u.Id = u2.Id
    ORDER BY 
        u.Id, 
        u2.Id /*Add an ORDER BY*/ 
    OPTION(MAXDOP 8);


/*

We must be careful with memory grants!
 * Bad estimates can inflate them
 * Selecting a lot of columns (especially strings) can inflate them
 * You can put data in order with indexes

 Some memory grant trivia:
  * One query can ask for 25% of max server memory
  * SQL Server will let ~75% of max server memory go to memory grants
  * https://www.erikdarlingdata.com/sql-server/the-great-memory-heist/

*/