﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
GO 

/*
██╗███╗   ██╗██████╗ ███████╗██╗  ██╗██╗███╗   ██╗ ██████╗ 
██║████╗  ██║██╔══██╗██╔════╝╚██╗██╔╝██║████╗  ██║██╔════╝ 
██║██╔██╗ ██║██║  ██║█████╗   ╚███╔╝ ██║██╔██╗ ██║██║  ███╗
██║██║╚██╗██║██║  ██║██╔══╝   ██╔██╗ ██║██║╚██╗██║██║   ██║
██║██║ ╚████║██████╔╝███████╗██╔╝ ██╗██║██║ ╚████║╚██████╔╝
╚═╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝ 
                                                           
███████╗ ██████╗ ██████╗ ████████╗███████╗                 
██╔════╝██╔═══██╗██╔══██╗╚══██╔══╝██╔════╝                 
███████╗██║   ██║██████╔╝   ██║   ███████╗                 
╚════██║██║   ██║██╔══██╗   ██║   ╚════██║                 
███████║╚██████╔╝██║  ██║   ██║   ███████║                 
╚══════╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝                 
*/



/*Multi-key index!*/

CREATE INDEX 
    multi_pass
ON dbo.Users
(
    Reputation,
    UpVotes,
    DownVotes,
    CreationDate DESC
) 
INCLUDE 
(
    DisplayName
) 
WITH
(MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

/*This query helps visualize how b-tree indexes store and order data*/
SELECT TOP (1000)
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate
FROM dbo.Users AS u
WHERE u.Reputation = 124
AND   u.UpVotes < 11
AND   u.DownVotes > 0
ORDER BY 
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate DESC;


/*
Run this a couple times first
*/
SELECT TOP (1000)
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate
FROM dbo.Users AS u
ORDER BY 
    u.UpVotes;
/*
Equality on first column, Order By second column
*/    
SELECT TOP (1000)
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate
FROM dbo.Users AS u
WHERE u.Reputation = 1
ORDER BY 
    u.UpVotes;



/*
Equality on first three columns
Order by fourth column
*/

SELECT TOP (1000)
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate
FROM dbo.Users AS u
WHERE u.Reputation = 1
AND   u.UpVotes = 0
AND   u.DownVotes = 0
ORDER BY 
    u.CreationDate DESC;


/*
Includes are Useless
*/
SELECT TOP (1000)
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate
FROM dbo.Users AS u
WHERE u.Reputation = 1
AND   u.UpVotes = 0
AND   u.DownVotes = 0
AND   u.CreationDate = '2013-12-31 23:59:23.147'
ORDER BY 
    u.DisplayName;





/*
Of course, inequalities are not so kind...
>, >=, <, <=, <>
*/

SELECT TOP (1000)
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate
FROM dbo.Users AS u
WHERE u.Reputation <= 1 
ORDER BY 
    u.UpVotes;

SELECT TOP (1000)
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate
FROM dbo.Users AS u
WHERE u.Reputation >= 1000000 
ORDER BY 
    u.UpVotes;

/*Because...*/
SELECT TOP (1000)
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate
FROM dbo.Users AS u
WHERE u.Reputation IN (124, 125)
AND   u.UpVotes < 11
AND   u.DownVotes > 0
ORDER BY 
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate DESC;   



/*Speaking of which, IN is also INEQUAL*/

SELECT TOP (1000)
    u.Reputation,
    u.UpVotes,
    u.DownVotes,
    u.CreationDate
FROM dbo.Users AS u
WHERE u.Reputation IN (1, 2)
ORDER BY 
    u.UpVotes;

/*Missing indexes are stupid about sorts*/

SELECT TOP (1000) 
    u.LastAccessDate
FROM dbo.Users AS u
WHERE u.Views = 0
ORDER BY 
    u.LastAccessDate;

