﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
DBCC DROPCLEANBUFFERS;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;

/*Only create these if you're really bored*/
CREATE INDEX 
   nowhere_fast 
ON dbo.Posts
    (OwnerUserId, LastActivityDate)
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    nowhere_fast 
ON dbo.Comments
    (UserId, CreationDate)
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    nowhere_fast 
ON dbo.Votes
    (UserId, CreationDate)
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 



/*
██████╗  █████╗ ████████╗ ██████╗██╗  ██╗
██╔══██╗██╔══██╗╚══██╔══╝██╔════╝██║  ██║
██████╔╝███████║   ██║   ██║     ███████║
██╔══██╗██╔══██║   ██║   ██║     ██╔══██║
██████╔╝██║  ██║   ██║   ╚██████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝   ╚═╝    ╚═════╝╚═╝  ╚═╝
                                         
███╗   ███╗ ██████╗ ██████╗ ███████╗     
████╗ ████║██╔═══██╗██╔══██╗██╔════╝     
██╔████╔██║██║   ██║██║  ██║█████╗       
██║╚██╔╝██║██║   ██║██║  ██║██╔══╝       
██║ ╚═╝ ██║╚██████╔╝██████╔╝███████╗     
╚═╝     ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝                                                      
*/





/*

Generally speaking, what kind of queries does Batch Mode help?
 * Unpredictable search patterns
 * Queries that process lots of rows!

Like this one. Big scans, non-SARGable predicates

*/
SELECT 
    u.Id,
    u.DisplayName,
    u.LastAccessDate,
    u.Reputation,
    y.LastActivityDate,
    Diff = 
        DATEDIFF(DAY, u.LastAccessDate, y.LastActivityDate)
FROM dbo.Users AS u
JOIN 
(
    SELECT 
        LastActivityDate = 
            MAX(x.LastActivityDate), 
        x.OwnerUserId
    FROM 
    (
    
        SELECT 
            p.LastActivityDate,
            p.OwnerUserId
        FROM dbo.Posts AS p
        
        UNION ALL
        
        SELECT 
            c.CreationDate, 
            c.UserId
        FROM dbo.Comments AS c
        
        UNION ALL
        
        SELECT 
            v.CreationDate, 
            v.UserId
        FROM dbo.Votes AS v
    
    ) AS x
    GROUP BY x.OwnerUserId
) AS y
    ON y.OwnerUserId = u.Id
WHERE DATEDIFF(DAY, u.LastAccessDate, y.LastActivityDate) >= (365 * 3)
ORDER BY y.LastActivityDate DESC;






















/*

Because I have in memory tempdb enabled, I can't use
a #temp table with a columnstore index on it here

CREATE TABLE #t (id int, INDEX c CLUSTERED COLUMNSTORE);

*/


CREATE TABLE 
    dbo.t                         -- This is new!
(                                 -- This is new!
    id int,                       -- This is new!
    INDEX c CLUSTERED COLUMNSTORE -- This is new!
);                                -- This is new!

SELECT 
    u.Id,
    u.DisplayName,
    u.LastAccessDate,
    u.Reputation,
    y.LastActivityDate,
    Diff = 
        DATEDIFF(DAY, u.LastAccessDate, y.LastActivityDate)
FROM dbo.Users AS u
LEFT JOIN dbo.t AS t ON 1 = 0 -- This is new!
JOIN 
(
    SELECT 
        LastActivityDate = 
            MAX(x.LastActivityDate), 
        x.OwnerUserId
    FROM 
    (
    
        SELECT 
            p.LastActivityDate,
            p.OwnerUserId
        FROM dbo.Posts AS p
        
        UNION ALL
        
        SELECT 
            c.CreationDate, 
            c.UserId
        FROM dbo.Comments AS c
        
        UNION ALL
        
        SELECT 
            v.CreationDate, 
            v.UserId
        FROM dbo.Votes AS v
    
    ) AS x
    GROUP BY x.OwnerUserId
) AS y
    ON y.OwnerUserId = u.Id
WHERE DATEDIFF(DAY, u.LastAccessDate, y.LastActivityDate) >= (365 * 3)
ORDER BY y.LastActivityDate DESC;
