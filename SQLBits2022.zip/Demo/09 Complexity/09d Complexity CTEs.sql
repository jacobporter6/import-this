﻿USE StackOverflow2013_Clean;
SET NOCOUNT ON; 
SET STATISTICS TIME, IO OFF; 
DBCC DROPCLEANBUFFERS;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013_Clean SET COMPATIBILITY_LEVEL = 140;


/*
Creating all these takes a few minutes
Pre-bake this demo or suffer the consequences
*/

CREATE INDEX 
    MissingIndex1
ON dbo.Posts 
    (CommunityOwnedDate,PostTypeId,Score)
INCLUDE 
    (OwnerUserId,ParentId);

CREATE INDEX 
    MissingIndex2
ON dbo.Posts 
    (ClosedDate,CommunityOwnedDate,PostTypeId,AcceptedAnswerId,Score)
INCLUDE 
    (OwnerUserId);

CREATE INDEX 
    MissingIndex3
ON dbo.Votes 
    (PostId,BountyAmount);

CREATE INDEX 
    MissingIndex4
ON dbo.Comments 
    (PostId)
INCLUDE 
    (Score);

CREATE INDEX 
    MissingIndex5
ON dbo.Comments 
    (UserId)
INCLUDE 
    (Score);

CREATE INDEX 
    MissingIndex6
ON dbo.Posts 
    (CommunityOwnedDate,ParentId,PostTypeId,Score)
INCLUDE 
    (OwnerUserId);

CREATE UNIQUE INDEX 
    MissingIndex7 
ON dbo.Users
    (Id, Reputation) 
INCLUDE 
    (DisplayName);

CREATE INDEX 
    MissingIndex8
ON dbo.Badges 
    (Name)
INCLUDE 
    (UserId);
GO 


/*
 ██████╗ ██████╗ ███╗   ███╗██████╗ ██╗     ███████╗██╗  ██╗██╗████████╗██╗   ██╗
██╔════╝██╔═══██╗████╗ ████║██╔══██╗██║     ██╔════╝╚██╗██╔╝██║╚══██╔══╝╚██╗ ██╔╝
██║     ██║   ██║██╔████╔██║██████╔╝██║     █████╗   ╚███╔╝ ██║   ██║    ╚████╔╝ 
██║     ██║   ██║██║╚██╔╝██║██╔═══╝ ██║     ██╔══╝   ██╔██╗ ██║   ██║     ╚██╔╝  
╚██████╗╚██████╔╝██║ ╚═╝ ██║██║     ███████╗███████╗██╔╝ ██╗██║   ██║      ██║   
 ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚═╝     ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝   ╚═╝      ╚═╝    

 ██████╗████████╗███████╗███████╗
██╔════╝╚══██╔══╝██╔════╝██╔════╝
██║        ██║   █████╗  ███████╗
██║        ██║   ██╔══╝  ╚════██║
╚██████╗   ██║   ███████╗███████║
 ╚═════╝   ╚═╝   ╚══════╝╚══════╝
*/



/*
Turn on query plans
*/


/*
Look at the query plan.
This always happens to me.
*/
DROP TABLE IF EXISTS #OurAppServer;
GO 

SELECT 
    cc.*
INTO #OurAppServer
FROM dbo.NotAComplicatedView AS cc
ORDER BY cc.Id;

/*

Can you tune this?

*/




















/*

Don't do this to yourself.
   
*/


--Turn off query plans for this, please God
EXEC sys.sp_helptext 
    @objname = N'dbo.NotAComplicatedView';

--It is now safe to turn query plans back on.

/*Break it up!*/





/*Let's stick that in a #temp table*/
DROP TABLE  
    IF EXISTS #NoSelfCollusion;

WITH 
    QuestionPostThing AS
(
    SELECT 
        p.Id, 
        p.OwnerUserId, 
        p.Score
    FROM dbo.Posts AS p
    WHERE p.PostTypeId = 1 /*Questions*/
    AND   p.Score > 0 /*Positive Score*/
    AND   p.AcceptedAnswerId > 0 /*Accepted Answer*/
    AND   p.ClosedDate IS NULL /*Not Closed*/
    AND   p.CommunityOwnedDate IS NULL /*Not Community Owned*/
    AND   EXISTS 
          ( 
              SELECT 
                  1/0 
              FROM dbo.Users AS u 
              WHERE u.Id = p.OwnerUserId 
              AND   u.Reputation >= 1000 
          )
),
    AnswerPostThing AS 
(
    SELECT 
        p.Id, 
        p.OwnerUserId, 
        p.Score, 
        p.ParentId
    FROM dbo.Posts AS p
    WHERE p.PostTypeId = 2 /*Aswers*/
    AND   p.Score > 0 /*Positive Score*/
    AND   p.CommunityOwnedDate IS NULL /*Not Community Owned*/
    AND   EXISTS 
          ( 
              SELECT 
                  1/0 
              FROM dbo.Users AS u 
              WHERE u.Id = p.OwnerUserId 
              AND   u.Reputation >= 1000 
          )
),
    NoSelfCollusion AS
(
    SELECT 
        AnswerId = a.Id, 
        AnswerOwnerUserId = a.OwnerUserId, 
        AnswerScore = a.Score, 
        QuestionId = q.Id, 
        QuestionOwnerUserId = q.OwnerUserId, 
        QuestionScore = q.Score
    FROM AnswerPostThing AS a
    JOIN QuestionPostThing AS q
        ON  a.ParentId = q.Id
        AND a.OwnerUserId <> q.OwnerUserId 
        /*Not Self Answered!*/
)
SELECT 
    n.*
INTO #NoSelfCollusion
FROM NoSelfCollusion AS n;























/*
What about the next step?
*/
DROP TABLE  
    IF EXISTS #Bounties;

WITH
    Bounties AS 
(
    SELECT 
        nc.AnswerId, 
        nc.AnswerOwnerUserId, 
        nc.AnswerScore, 
        nc.QuestionId, 
        nc.QuestionOwnerUserId, 
        nc.QuestionScore,
        v.BountyAmount
    FROM #NoSelfCollusion AS nc
    JOIN dbo.Votes AS v
        ON nc.AnswerId = v.PostId
        OR nc.QuestionId = v.PostId
    WHERE v.BountyAmount IS NOT NULL
)
SELECT 
    b.*
INTO #Bounties
FROM Bounties AS b;





























/*
^^^^^^^^^^^
OR OR OR OR

NOT
*/
DROP TABLE  
    IF EXISTS #Bounties;

WITH
    Bounties AS 
(
    SELECT 
        nc.AnswerId, 
        nc.AnswerOwnerUserId, 
        nc.AnswerScore, 
        nc.QuestionId, 
        nc.QuestionOwnerUserId, 
        nc.QuestionScore,
        v.BountyAmount
    FROM #NoSelfCollusion AS nc
    JOIN dbo.Votes AS v
        ON nc.AnswerId = v.PostId
    WHERE v.BountyAmount IS NOT NULL

    UNION ALL

    SELECT 
        nc.AnswerId, 
        nc.AnswerOwnerUserId, 
        nc.AnswerScore, 
        nc.QuestionId, 
        nc.QuestionOwnerUserId, 
        nc.QuestionScore,
        v.BountyAmount
    FROM #NoSelfCollusion AS nc
    JOIN dbo.Votes AS v
        ON nc.QuestionId = v.PostId
    WHERE v.BountyAmount IS NOT NULL
)
SELECT 
    b.*
INTO #Bounties
FROM Bounties AS b;
























/*
Final query
*/
DROP TABLE 
    IF EXISTS #OurAppServer;

SELECT 
    u.Id, 
    u.DisplayName,
    QuestionScoreSum = 
        SUM(b.QuestionScoreSum),
    AnswerScoreSum = 
        SUM(b.AnswerScoreSum),
    BountySum = 
        SUM(b.BountySum),
    AnswerCommentScore = 
        SUM(b.AnswerCommentScore),
    QuestionCommentScore = 
        SUM(b.QuestionCommentScore)
INTO #OurAppServer /*Discard results!*/
FROM dbo.Users AS u
JOIN 
(
    SELECT
        b.AnswerOwnerUserId,
        b.QuestionOwnerUserId,
        QuestionScoreSum = 
            SUM(b.QuestionScore * 1.0),
        AnswerScoreSum = 
            SUM(b.AnswerScore * 1.0),
        BountySum = 
            SUM(b.BountyAmount * 1.0),
        AnswerCommentScore = 
            (
                SELECT 
                    SUM(c.Score) 
                FROM dbo.Comments AS c 
                WHERE c.PostId = b.AnswerId
            ),
        QuestionCommentScore = 
            (
                SELECT 
                    SUM(c.Score) 
                FROM dbo.Comments AS c 
                WHERE c.PostId = b.QuestionId
            )
    FROM #Bounties AS b
    GROUP BY 
        b.AnswerOwnerUserId, 
        b.QuestionOwnerUserId, 
        b.AnswerId, 
        b.QuestionId
) AS b
    ON u.Id = b.AnswerOwnerUserId
    OR u.Id = b.QuestionOwnerUserId
WHERE u.Reputation >= 1000
AND u.Id IN 
    (
        SELECT 
            b.UserId
        FROM dbo.Badges AS b
        WHERE b.Name IN 
              (
                  N'Nice Question',
                  N'Good Question', 
                  N'Great Question', 
                  N'Great Answer',
                  N'Nice Answer', 
                  N'Good Answer' 
              )
    )
GROUP BY 
    u.Id, 
    u.DisplayName
ORDER BY u.Id;




















































/*
All together?

Turn off query plans to show the difference, too
*/

DROP TABLE  
    IF EXISTS #NoSelfCollusion;
DROP TABLE  
    IF EXISTS #Bounties;
DROP TABLE 
    IF EXISTS #OurAppServer;
GO 

WITH 
    QuestionPostThing AS
(
    SELECT 
        p.Id, 
        p.OwnerUserId, 
        p.Score
    FROM dbo.Posts AS p
    WHERE p.PostTypeId = 1 /*Questions*/
    AND   p.Score > 0 /*Positive Score*/
    AND   p.AcceptedAnswerId > 0 /*Accepted Answer*/
    AND   p.ClosedDate IS NULL /*Not Closed*/
    AND   p.CommunityOwnedDate IS NULL /*Not Community Owned*/
    AND   EXISTS 
          ( 
              SELECT 
                  1/0 
              FROM dbo.Users AS u 
              WHERE u.Id = p.OwnerUserId 
              AND   u.Reputation >= 1000 
          )
),
    AnswerPostThing AS 
(
    SELECT 
        p.Id, 
        p.OwnerUserId, 
        p.Score, 
        p.ParentId
    FROM dbo.Posts AS p
    WHERE p.PostTypeId = 2 /*Aswers*/
    AND   p.Score > 0 /*Positive Score*/
    AND   p.CommunityOwnedDate IS NULL /*Not Community Owned*/
    AND   EXISTS 
          ( 
              SELECT 
                  1/0 
              FROM dbo.Users AS u 
              WHERE u.Id = p.OwnerUserId 
              AND   u.Reputation >= 1000 
          )
),
    NoSelfCollusion AS
(
    SELECT 
        AnswerId = a.Id, 
        AnswerOwnerUserId = a.OwnerUserId, 
        AnswerScore = a.Score, 
        QuestionId = q.Id, 
        QuestionOwnerUserId = q.OwnerUserId, 
        QuestionScore = q.Score
    FROM AnswerPostThing AS a
    JOIN QuestionPostThing AS q
        ON  a.ParentId = q.Id
        AND a.OwnerUserId <> q.OwnerUserId 
        /*Not Self Answered!*/
)
SELECT 
    n.*
INTO #NoSelfCollusion
FROM NoSelfCollusion AS n;


WITH
    Bounties AS 
(
    SELECT 
        nc.AnswerId, 
        nc.AnswerOwnerUserId, 
        nc.AnswerScore, 
        nc.QuestionId, 
        nc.QuestionOwnerUserId, 
        nc.QuestionScore,
        v.BountyAmount
    FROM #NoSelfCollusion AS nc
    JOIN dbo.Votes AS v
        ON nc.AnswerId = v.PostId
    WHERE v.BountyAmount IS NOT NULL

    UNION ALL

    SELECT 
        nc.AnswerId, 
        nc.AnswerOwnerUserId, 
        nc.AnswerScore, 
        nc.QuestionId, 
        nc.QuestionOwnerUserId, 
        nc.QuestionScore,
        v.BountyAmount
    FROM #NoSelfCollusion AS nc
    JOIN dbo.Votes AS v
        ON nc.QuestionId = v.PostId
    WHERE v.BountyAmount IS NOT NULL
)
SELECT 
    b.*
INTO #Bounties
FROM Bounties AS b;


SELECT 
    u.Id, 
    u.DisplayName,
    QuestionScoreSum = 
        SUM(b.QuestionScoreSum),
    AnswerScoreSum = 
        SUM(b.AnswerScoreSum),
    BountySum = 
        SUM(b.BountySum),
    AnswerCommentScore = 
        SUM(b.AnswerCommentScore),
    QuestionCommentScore = 
        SUM(b.QuestionCommentScore)
INTO #OurAppServer /*Discard results!*/
FROM dbo.Users AS u
JOIN 
(
    SELECT
        b.AnswerOwnerUserId,
        b.QuestionOwnerUserId,
        QuestionScoreSum = 
            SUM(b.QuestionScore * 1.0),
        AnswerScoreSum = 
            SUM(b.AnswerScore * 1.0),
        BountySum = 
            SUM(b.BountyAmount * 1.0),
        AnswerCommentScore = 
            (
                SELECT 
                    SUM(c.Score) 
                FROM dbo.Comments AS c 
                WHERE c.PostId = b.AnswerId
            ),
        QuestionCommentScore = 
            (
                SELECT 
                    SUM(c.Score) 
                FROM dbo.Comments AS c 
                WHERE c.PostId = b.QuestionId
            )
    FROM #Bounties AS b
    GROUP BY 
        b.AnswerOwnerUserId, 
        b.QuestionOwnerUserId, 
        b.AnswerId, 
        b.QuestionId
) AS b
    ON u.Id = b.AnswerOwnerUserId
    OR u.Id = b.QuestionOwnerUserId
WHERE u.Reputation >= 1000
AND u.Id IN 
    (
        SELECT 
            b.UserId
        FROM dbo.Badges AS b
        WHERE b.Name IN 
              (
                  N'Nice Question',
                  N'Good Question', 
                  N'Great Question', 
                  N'Great Answer',
                  N'Nice Answer', 
                  N'Good Answer' 
              )
    )
GROUP BY 
    u.Id, 
    u.DisplayName
ORDER BY u.Id;
