﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
GO 

CREATE INDEX 
    scan_b_gone
ON dbo.Posts 
    (OwnerUserId, PostTypeId) 
INCLUDE 
    (ParentId, Score) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

/*
██╗███╗   ██╗██████╗ ███████╗██╗  ██╗             
██║████╗  ██║██╔══██╗██╔════╝╚██╗██╔╝             
██║██╔██╗ ██║██║  ██║█████╗   ╚███╔╝              
██║██║╚██╗██║██║  ██║██╔══╝   ██╔██╗              
██║██║ ╚████║██████╔╝███████╗██╔╝ ██╗             
╚═╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝             
                                                  
███████╗██████╗  ██████╗  ██████╗ ██╗     ███████╗
██╔════╝██╔══██╗██╔═══██╗██╔═══██╗██║     ██╔════╝
███████╗██████╔╝██║   ██║██║   ██║██║     ███████╗
╚════██║██╔═══╝ ██║   ██║██║   ██║██║     ╚════██║
███████║██║     ╚██████╔╝╚██████╔╝███████╗███████║
╚══════╝╚═╝      ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
*/



/*

Both MAX and TOP (1) are sensitive to this

Look at the saved plan, don't run these.

Get the estimated plans, though!

*/

SELECT 
    pq.OwnerUserId, 
    pq.Score, 
    pq.Title, 
    pq.CreationDate,
    pa.OwnerUserId, 
    pa.Score, 
    pa.CreationDate
FROM dbo.Posts AS pa
INNER JOIN dbo.Posts AS pq
    ON pq.Id = pa.ParentId
WHERE pq.PostTypeId = 1
AND   pq.CommunityOwnedDate IS NULL
AND   pq.AnswerCount > 1
AND   pa.PostTypeId = 2
AND   pa.OwnerUserId = 22656
AND   pa.Score >
(
    SELECT 
        MAX(ps.Score)
    FROM dbo.Posts AS ps
    WHERE ps.ParentId = pa.ParentId 
    AND   ps.Id <> pa.Id
)
ORDER BY pq.Id;



SELECT 
    pq.OwnerUserId, 
    pq.Score, 
    pq.Title, 
    pq.CreationDate,
    pa.OwnerUserId, 
    pa.Score, 
    pa.CreationDate
FROM dbo.Posts AS pa
INNER JOIN dbo.Posts AS pq
    ON pq.Id = pa.ParentId
WHERE pq.PostTypeId = 1
AND   pq.CommunityOwnedDate IS NULL
AND   pq.AnswerCount > 1
AND   pa.PostTypeId = 2
AND   pa.OwnerUserId = 22656
AND   pa.Score >
(
    SELECT TOP (1) 
        ps.Score
    FROM dbo.Posts AS ps
    WHERE ps.ParentId = pa.ParentId 
    AND   ps.Id <> pa.Id
    ORDER BY ps.Score DESC
)
ORDER BY pq.Id;




/*
Get on up
*/
CREATE INDEX 
    spool_b_gone 
ON dbo.Posts
    (ParentId, Score) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);


/*

Eager index spools happen (usually) when:
 * You have a nested loops join
 * There's no good index on the inner side

Why I kind of hate them:
 * No missing index request
 * Index build is single threaded, even in a parallel plan
 * EXECSYNC waits in a parallel plan, nothing in a serial plan
 * Spools load data row by row, no optimizations
 * Stored in tempdb, thrown away after query finishes
 * You can have write the same data out to multiple spools

How to fix them:
 * Look at the spool definition:
  * Treat seeks like key columns
  * Treat output like included columns
  * Be mindful of sorting/sort direction


*/