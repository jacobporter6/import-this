﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
GO 

CREATE INDEX 
    badges 
ON dbo.Badges 
    (Name, UserId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    not_badges 
ON dbo.Posts 
    (PostTypeId, OwnerUserId) 
INCLUDE 
    (Score) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 

/*
████████╗ █████╗ ██████╗ ██╗     ███████╗         
╚══██╔══╝██╔══██╗██╔══██╗██║     ██╔════╝         
   ██║   ███████║██████╔╝██║     █████╗           
   ██║   ██╔══██║██╔══██╗██║     ██╔══╝           
   ██║   ██║  ██║██████╔╝███████╗███████╗         
   ╚═╝   ╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝         
                                                  
███████╗██████╗  ██████╗  ██████╗ ██╗     ███████╗
██╔════╝██╔══██╗██╔═══██╗██╔═══██╗██║     ██╔════╝
███████╗██████╔╝██║   ██║██║   ██║██║     ███████╗
╚════██║██╔═══╝ ██║   ██║██║   ██║██║     ╚════██║
███████║██║     ╚██████╔╝╚██████╔╝███████╗███████║
╚══════╝╚═╝      ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
*/



/*

Spools like crazy, but a table spool this time.

Again, inner side of nested loops!

Technically it has a clustered index on the temporary object,
but it's not on any of the columns in your data. 

Things to look at:
 * Rebinds: Cache miss
 * Rewinds: Cache hit

Rebinds will re-execute the branch below the spool operator.
Rewinds will re-read data currently in the spooled object

* If there are a lot of rebinds compared to rewinds, was the spool useful?
* What can we do to reduce the need for a spool like this?

*/
SELECT 
    b.UserId,
    SummerHere = 
        SUM(p.Score)
FROM dbo.Badges AS b
CROSS APPLY
(
    SELECT 
        p.Score,
        p.OwnerUserId,
        ScoreOrder = 
            ROW_NUMBER() OVER 
            ( 
                PARTITION BY 
                    p.OwnerUserId 
                ORDER BY     
                    p.Score DESC 
            )
    FROM dbo.Posts AS p
    WHERE p.PostTypeId IN (1, 2)
    AND   p.OwnerUserId = b.UserId
) AS p 
WHERE p.ScoreOrder = 0
AND   b.Name IN 
      ( 
          N'Popular Question', N'Notable Question', N'Nice Question',
          N'Good Question', N'Famous Question', N'Favorite Question',
          N'Great Question', N'Stellar Question' 
      )
GROUP BY b.UserId
ORDER BY b.UserId;



/*
A trick Paul White showed me; doesn't need a temp table

Put a distinct on the UserId column so the optimizer doesn't
need a spool to make the inner side of the nested loop more efficient.

Each row from the outer side of the nested loop is guaranteed to
have a unique value passed to the inner side of the nested loop!

*/
SELECT 
    b.UserId,
    SummerHere = 
        SUM(p.Score)
FROM 
( 
    SELECT DISTINCT 
        b.UserId 
    FROM dbo.Badges AS b 
    WHERE b.Name IN 
          ( 
              N'Popular Question', N'Notable Question', N'Nice Question',
              N'Good Question', N'Famous Question', N'Favorite Question',
              N'Great Question', N'Stellar Question' 
          ) 
) AS b
CROSS APPLY
(
    SELECT 
        p.Score,
        p.OwnerUserId,
        ScoreOrder = 
            ROW_NUMBER() OVER 
            ( 
                PARTITION BY 
                    p.OwnerUserId 
                ORDER BY 
                    p.Score DESC 
            )
    FROM dbo.Posts AS p
    WHERE p.PostTypeId IN (1, 2)
    AND   p.OwnerUserId = b.UserId
) AS p 
WHERE p.ScoreOrder = 0
GROUP BY b.UserId
ORDER BY b.UserId;


/*

My usual method with a temp table
Doesn't need an index, but probably wouldn't hurt either

Same idea: pass distinct values.

*/
SELECT DISTINCT 
    b.UserId 
INTO #Badges 
FROM dbo.Badges AS b 
WHERE b.Name IN 
      ( 
          N'Popular Question', N'Notable Question', N'Nice Question',
          N'Good Question', N'Famous Question', N'Favorite Question',
          N'Great Question', N'Stellar Question' 
      );

SELECT 
    b.UserId,
    SummerHere = 
        SUM(p.Score)
FROM #Badges AS b
CROSS APPLY
(
    SELECT 
        p.Score,
        p.OwnerUserId,
        ScoreOrder = 
            ROW_NUMBER() OVER 
            ( 
                PARTITION BY 
                    p.OwnerUserId 
                 ORDER BY 
                     p.Score DESC 
            )
    FROM dbo.Posts AS p
    WHERE p.PostTypeId IN (1, 2)
    AND   p.OwnerUserId = b.UserId
) AS p 
WHERE p.ScoreOrder = 0
GROUP BY b.UserId
ORDER BY b.UserId;
