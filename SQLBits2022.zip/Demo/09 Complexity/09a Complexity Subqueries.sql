﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
GO 

/*25*/
/*Show them stuff while these creates, dummy*/
CREATE INDEX 
    north 
ON dbo.Votes
    (PostId) 
WITH(MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    south 
ON dbo.Badges
    (UserId, Date) 
WITH(MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    east 
ON dbo.Posts
    (PostTypeId, Score, OwnerUserId) 
WITH(MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    west 
ON dbo.Comments
    (UserId, PostId) 
WITH(MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 


/*
 ██████╗ ██████╗ ███╗   ███╗██████╗ ██╗     ███████╗██╗  ██╗██╗████████╗██╗   ██╗
██╔════╝██╔═══██╗████╗ ████║██╔══██╗██║     ██╔════╝╚██╗██╔╝██║╚══██╔══╝╚██╗ ██╔╝
██║     ██║   ██║██╔████╔██║██████╔╝██║     █████╗   ╚███╔╝ ██║   ██║    ╚████╔╝ 
██║     ██║   ██║██║╚██╔╝██║██╔═══╝ ██║     ██╔══╝   ██╔██╗ ██║   ██║     ╚██╔╝  
╚██████╗╚██████╔╝██║ ╚═╝ ██║██║     ███████╗███████╗██╔╝ ██╗██║   ██║      ██║   
 ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚═╝     ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝   ╚═╝      ╚═╝    
*/



/*
I lied to you a little bit...

Yeah, the function made this sucky and slow serial.

But why was it still not very fast parallel?
*/

DROP TABLE IF EXISTS #t;
GO 

SELECT   
    u.Id,
    u.Reputation,
    u.DisplayName, 
    TopPostScore = /*This gets a particularly bad estimate, spills, blah blah blah*/
    ( 
        SELECT 
            MAX(p.Score) 
        FROM dbo.Posts AS p 
        WHERE p.OwnerUserId = u.Id 
        AND p.PostTypeId IN (1, 2) 
    ),
    TopCommentScore = 
    ( 
        SELECT 
            MAX(c.Score) 
        FROM dbo.Comments AS c 
        WHERE c.UserId = u.Id 
    ),
    LatestBadge = 
    ( 
        SELECT TOP (1) 
            b.Name
        FROM dbo.Badges AS b
        WHERE b.UserId = u.Id
        ORDER BY b.Date DESC 
    ),
    PostId = 
        p.Id,
    p.Title,
    VoteCount = 
    ( 
        SELECT 
            COUNT_BIG(*) 
        FROM dbo.Votes AS v 
        WHERE v.PostId = p.Id 
    )
INTO #t
FROM dbo.Users AS u
JOIN dbo.Posts AS p
    ON p.OwnerUserId = u.Id
WHERE u.Reputation >= 1000
AND   p.PostTypeId = 1
AND   p.Score >= 1000 
ORDER BY u.Reputation DESC;
/*What's still slow here?*/




/*
Could we switch things up?
*/      
    
    
DROP TABLE IF EXISTS #t;
GO 

SELECT   
    u.Id,
    u.Reputation,
    FormattedDisplayName = 
        dbo.InitialCap(u.DisplayName),
    TopCommentScore = 
    ( 
        SELECT 
            MAX(c.Score) 
        FROM dbo.Comments AS c 
        WHERE c.UserId = u.Id 
    ),
    LatestBadge = 
    ( 
        SELECT TOP (1) 
            b.Name
        FROM dbo.Badges AS b
        WHERE b.UserId = u.Id
        ORDER BY b.Date DESC 
    ),
    PostId = 
        p.Id,
    p.Title,
    VoteCount = 
    ( 
        SELECT 
            COUNT_BIG(*) 
        FROM dbo.Votes AS v 
        WHERE v.PostId = p.Id 
    )
INTO #t
FROM dbo.Users AS u
JOIN dbo.Posts AS p
    ON p.OwnerUserId = u.Id
WHERE u.Reputation >= 1000
AND   p.PostTypeId = 1
AND   p.Score >= 1000 
ORDER BY u.Reputation DESC;


/*Dammitall*/
SELECT 
    t.Id, 
    t.Reputation, 
    t.FormattedDisplayName,
    TopPostScore =  /*It uh, still gets a bad estimate here*/
        ( 
            SELECT 
                MAX(p.Score) 
            FROM dbo.Posts AS p 
            WHERE p.OwnerUserId = t.Id 
            AND   p.PostTypeId IN (1, 2) 
        ),
    t.TopCommentScore, 
    t.LatestBadge,
    t.PostId, 
    t.Title, 
    t.VoteCount
FROM #t AS t
ORDER BY t.Reputation DESC;



/*

I tried very hard for you.

Go look at the complexity nopes plans

There were a lot of rewrites that failed miserably!

*/

/*NOPE*/
SELECT 
    t.Id, 
    t.Reputation, 
    t.FormattedDisplayName,
    TopPostScore = 
        ( 
            SELECT TOP (1) 
                p.Score
            FROM dbo.Posts AS p 
            WHERE p.OwnerUserId = t.Id 
            AND   p.PostTypeId IN (1, 2) 
            ORDER BY p.Score DESC 
        ),
    t.TopCommentScore, 
    t.LatestBadge,
    t.PostId, 
    t.Title, 
    t.VoteCount
FROM #t AS t
ORDER BY t.Reputation DESC;

/*STILL NOPE*/
SELECT 
    Id, 
    t.Reputation, 
    t.FormattedDisplayName,
    TopPostScore = 
        ( 
            SELECT TOP (1) 
                p.Score
            FROM 
            (
                SELECT TOP (1) 
                    p.Score
                FROM dbo.Posts AS p 
                WHERE p.OwnerUserId = t.id 
                AND   p.PostTypeId = 1
                ORDER BY p.Score DESC 
                
                UNION ALL
                
                SELECT TOP (1) 
                    p.Score
                FROM dbo.Posts AS p 
                WHERE p.OwnerUserId = t.id 
                AND   p.PostTypeId = 2
                ORDER BY p.Score DESC 
            ) AS p
            ORDER BY p.Score DESC
        ),
    t.TopCommentScore, 
    t.LatestBadge,
    t.PostId, 
    t.Title, 
    t.VoteCount
FROM #t AS t
ORDER BY t.Reputation DESC;



/*DEFINITELY NOPE*/
SELECT 
    t.Id, 
    t.Reputation, 
    t.FormattedDisplayName,
    TopPostScore = 
        ( 
            SELECT 
                MAX(p.Score) AS Score
            FROM 
            (
                SELECT TOP (1) 
                    p.Score
                FROM dbo.Posts AS p 
                WHERE p.OwnerUserId = t.Id 
                AND   p.PostTypeId = 1
                ORDER BY p.Score DESC 
                
                UNION ALL
                
                SELECT TOP (1) 
                    p.Score
                FROM dbo.Posts AS p 
                WHERE p.OwnerUserId = t.Id 
                AND   p.PostTypeId = 2
                ORDER BY p.Score DESC 
            ) AS p
        ),
    t.TopCommentScore, 
    t.LatestBadge,
    t.PostId, 
    t.Title, 
    t.VoteCount
FROM #t AS t
ORDER BY t.Reputation DESC;



/*HARD NOPE*/
SELECT 
    t.Id, 
    t.Reputation, 
    t.FormattedDisplayName,
    TopPostScore = 
        ( 
            SELECT TOP (1) 
                p.Score
            FROM 
            (
                SELECT 
                    MAX(p.Score) AS Score
                FROM dbo.Posts AS p 
                WHERE p.OwnerUserId = t.Id 
                AND   p.PostTypeId = 1
                
                UNION ALL
                
                SELECT 
                    MAX(p.Score) AS Score
                FROM dbo.Posts AS p 
                WHERE p.OwnerUserId = t.Id 
                AND   p.PostTypeId = 2
            ) AS p
            ORDER BY p.Score DESC
        ),
    t.TopCommentScore, 
    t.LatestBadge,
    t.PostId, 
    t.Title, 
    t.VoteCount
FROM #t AS t
ORDER BY t.Reputation DESC;


/*EVERY NOPE*/
SELECT 
    t.Id, 
    t.Reputation, 
    t.FormattedDisplayName,
    q_score = 
        (
            SELECT TOP (1) 
                p.Score
            FROM dbo.Posts AS p
            WHERE p.PostTypeId = 1
            AND   p.OwnerUserId = t.Id
            ORDER BY p.Score DESC
        ),
    a_score = 
        (
            SELECT TOP (1) 
                p.Score
            FROM dbo.Posts AS p
            WHERE p.PostTypeId = 2
            AND   p.OwnerUserId = t.Id
            ORDER BY p.Score DESC
        ),
    t.TopCommentScore, 
    t.LatestBadge,
    t.PostId, 
    t.Title, 
    t.VoteCount
FROM #t AS t
ORDER BY t.Reputation DESC;



/*
Finally...

Let's think about this a little bit:
 * We get a bad estimate looking for PostTypeId IN (1, 2)
  * What happens if we separate that out?
   * Better estimates?
   * Are both slow?

*/
SELECT 
    t.Id, 
    t.Reputation, 
    t.FormattedDisplayName,
    pq.Score,
    t.TopCommentScore, 
    t.LatestBadge,
    t.PostId, 
    t.Title, 
    t.VoteCount
FROM #t AS t
OUTER APPLY /*This one is fast*/
(
    SELECT TOP (1) 
        p.Score
    FROM dbo.Posts AS p
    WHERE p.PostTypeId = 1
    AND   p.OwnerUserId = t.Id
    ORDER BY p.Score DESC
) AS pq
ORDER BY t.Reputation DESC;




/*

Don't run this, it takes forever. Look at the saved plan.

*/
SELECT 
    t.Id, 
    t.Reputation, 
    t.FormattedDisplayName,
    pa.Score,
    t.TopCommentScore, 
    t.LatestBadge,
    t.PostId, 
    t.Title, 
    t.VoteCount
FROM #t AS t
OUTER APPLY /*This two is slow...*/
(
    SELECT TOP (1) 
        p.Score
    FROM dbo.Posts AS p
    WHERE p.PostTypeId = 2
    AND   p.OwnerUserId = t.Id
    ORDER BY p.Score DESC
) AS pa
ORDER BY t.Reputation DESC;



/*
PostTypeId seems to be the bad guy here.

Much slower than PostTypeId 1!

Can we express this differently?

What is it we care about?

( 
  SELECT 
      MAX(p.Score) <<<<< The highest score
  FROM dbo.Posts AS p 
  WHERE p.OwnerUserId = u.Id 
  AND   p.PostTypeId IN (1, 2) <<<<< For either of these Post Types
) AS TopPostScore,

If we get all the high scores for PostTypeId 1,
how can we use them to filter out lower scores for PostTypeId 2?

There are a lot of possible ways to do this, but...

*/


















SELECT 
    t.Id, 
    t.Reputation, 
    t.FormattedDisplayName,
    TopPostScore = 
        ISNULL(pa.Score, pq.Score),
    t.TopCommentScore, 
    t.LatestBadge,
    t.PostId, 
    t.Title, 
    t.VoteCount
FROM #t AS t
OUTER APPLY /*This one is fast*/
(
    SELECT TOP (1) 
        p.Score /*Let's get the top score here*/
    FROM dbo.Posts AS p
    WHERE p.PostTypeId = 1
    AND   p.OwnerUserId = t.Id
    ORDER BY p.Score DESC
) AS pq
OUTER APPLY /*This two isn't slow anymore!*/
(
    SELECT TOP (1) 
        p.Score
    FROM dbo.Posts AS p
    WHERE p.PostTypeId = 2
    AND   p.OwnerUserId = t.Id
    AND   pq.Score < p.Score /*Then use it as a filter down here*/
    ORDER BY p.Score DESC
) AS pa
ORDER BY t.Reputation DESC;

/*

Much faster!
 * Additional seek 
 * No longer need to return all rows for PostTypeId 2 and compare
 * Extra filter means fewer rows, means faster query
 * You can set a clock to that

*/

