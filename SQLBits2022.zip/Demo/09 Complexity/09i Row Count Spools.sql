﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
GO 

CREATE INDEX 
    v 
ON dbo.Votes
    (VoteTypeId, PostId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    p 
ON dbo.Posts
    (PostTypeId, AcceptedAnswerId) 
INCLUDE
    (CreationDate) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

/*
██████╗  ██████╗ ██╗    ██╗                       
██╔══██╗██╔═══██╗██║    ██║                       
██████╔╝██║   ██║██║ █╗ ██║                       
██╔══██╗██║   ██║██║███╗██║                       
██║  ██║╚██████╔╝╚███╔███╔╝                       
╚═╝  ╚═╝ ╚═════╝  ╚══╝╚══╝                        
                                                  
 ██████╗ ██████╗ ██╗   ██╗███╗   ██╗████████╗     
██╔════╝██╔═══██╗██║   ██║████╗  ██║╚══██╔══╝     
██║     ██║   ██║██║   ██║██╔██╗ ██║   ██║        
██║     ██║   ██║██║   ██║██║╚██╗██║   ██║        
╚██████╗╚██████╔╝╚██████╔╝██║ ╚████║   ██║        
 ╚═════╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝   ╚═╝        
                                                  
███████╗██████╗  ██████╗  ██████╗ ██╗     ███████╗
██╔════╝██╔══██╗██╔═══██╗██╔═══██╗██║     ██╔════╝
███████╗██████╔╝██║   ██║██║   ██║██║     ███████╗
╚════██║██╔═══╝ ██║   ██║██║   ██║██║     ╚════██║
███████║██║     ╚██████╔╝╚██████╔╝███████╗███████║
╚══════╝╚═╝      ╚═════╝  ╚═════╝ ╚══════╝╚══════╝
*/

/*

An old but still relevant blog post:
 * https://techcommunity.microsoft.com/t5/sql-server-blog/subqueries-in-case-expressions/ba-p/383140

A rowcount spool shows up to keep track of the exists in the case expression

*/
SELECT 
    x.YearPeriod,
    MonthPeriod = 
        RIGHT('00' + RTRIM(x.MonthPeriod), 2),
    PercentAnswered = 
        CONVERT
        (
            decimal(18,2), 
            (SUM(x.AnsweredQuestion * 1.) / 
                (COUNT(*) * 1.)) * 100.
        )
FROM
(
    SELECT 
        YearPeriod = 
            YEAR(p.CreationDate),
        MonthPeriod = 
            MONTH(p.CreationDate),
        AnsweredQuestion = 
            CASE 
                WHEN EXISTS
                     ( 
                         SELECT 
                             1/0
                         FROM dbo.Votes AS v
                         WHERE v.PostId = p.AcceptedAnswerId
                         AND   v.VoteTypeId = 1 
                     ) 
                 THEN 1
                 ELSE 0
            END
    FROM dbo.Posts AS p
    WHERE p.PostTypeId = 1
) AS x
GROUP BY 
    x.YearPeriod, 
    x.MonthPeriod
ORDER BY 
    x.YearPeriod ASC, 
    x.MonthPeriod ASC;






/*

Same logic, just moving the case expression to outer apply.

*/
SELECT 
    x.YearPeriod,
    MonthPeriod = 
        RIGHT('00' + RTRIM(x.MonthPeriod), 2),
    PercentAnswered = 
    CONVERT
    (
        decimal(18,2), 
        (SUM(x.AnsweredQuestion * 1.) / 
            (COUNT(*) * 1.)) * 100.
    )
FROM
(
    SELECT 
        YearPeriod = 
            YEAR(p.CreationDate),
        MonthPeriod = 
            MONTH(p.CreationDate),
        oa.AnsweredQuestion
    FROM dbo.Posts AS p
    --LEFT JOIN dbo.t ON 1 = 0
    /*Show batch mode*/
    OUTER APPLY 
    (
        SELECT 
            AnsweredQuestion = 
                CASE 
                    WHEN v.Id IS NOT NULL 
                    THEN 1 
                    ELSE 0 
                END
        FROM dbo.Votes AS v
        WHERE v.PostId = p.AcceptedAnswerId
        AND   v.VoteTypeId = 1
    ) oa
    WHERE p.PostTypeId = 1
) AS x
GROUP BY 
    x.YearPeriod, 
    x.MonthPeriod
ORDER BY 
    x.YearPeriod ASC, 
    x.MonthPeriod ASC;

/*

What changed?
 * Join order
 * Join type

In the slower query, the semi-join from Posts to Votes
uses Nested Loops, which is common when you put subqueries
in a select list, even without a case expression.

Using outer apply opens the optimizer up to using different join orders
and types. Remember that the joins you see to implement subqueries
can't ever reduce row counts; they either match or return a NULL.

Outer join and apply are the same in that regard.

*/


/*
BEWARE NULLABLE COLUMNS
*/

/*
If you use not in with NULL values, you get bad results
*/

DECLARE 
    @good table  
(
    id int NOT NULL    
);

DECLARE 
    @bad table 
(
    id int NULL
);

INSERT 
    @good 
(
    id
) 
VALUES 
    (1);

INSERT 
    @bad 
(
    id
) 
VALUES 
    (NULL); /*Change this to 2*/

SELECT 
    records = 
        COUNT_BIG(*) /*Should be 1, or something*/
FROM @good AS g
WHERE g.id NOT IN
      (
          SELECT 
              b.id 
          FROM @bad AS b
      );


/*
Populate these while you talk about the query plan, dummy.
*/


/*
Both of these tables have NULLable columns in them...
*/
CREATE TABLE 
    #OldUsers
(
    UserId int NULL
);

CREATE TABLE 
    #NewUsers
(
    UserId int NULL
);

/*
But neither one will have any NULL values at all!
*/
INSERT 
    #OldUsers WITH (TABLOCK)
(
    UserId
)
SELECT 
    p.OwnerUserId
FROM dbo.Posts AS p
WHERE p.OwnerUserId IS NOT NULL;

INSERT 
    #NewUsers WITH (TABLOCK)
(
    UserId
)
SELECT 
    c.UserId
FROM dbo.Comments AS c
WHERE c.UserId IS NOT NULL;


/*

SQL Server has to come up with a query plan to handle NULLs, though.

And it's a nightmare.

*/
SELECT 
    records = COUNT_BIG(*) 
FROM #NewUsers AS nu
WHERE nu.UserId NOT IN 
      (
          SELECT 
              ou.UserId 
          FROM #OldUsers AS ou
      );

/*

Not exists doesn't have those problems.

*/
SELECT 
    records = COUNT_BIG(*) 
FROM #NewUsers AS nu
WHERE NOT EXISTS 
      (
          SELECT 
              1/0 
          FROM #OldUsers AS ou 
          WHERE nu.UserId = ou.UserId
      );

/*

Takeaways:
 * IN and NOT IN, I use for lists of literal values
 * EXISTS and NOT EXISTS, I use for correlations to tables

IN doesn't have semantic issues with NULLs, but I like to keep
things consistent in my queries, to set a good example for others.

*/