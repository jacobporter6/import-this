﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
GO 

CREATE INDEX 
    yourmom 
ON dbo.Users 
    (Reputation) 
INCLUDE 
    (Id, DisplayName)
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 

/*
██╗███████╗███████╗██╗   ██╗
██║██╔════╝██╔════╝╚██╗ ██╔╝
██║█████╗  █████╗   ╚████╔╝ 
██║██╔══╝  ██╔══╝    ╚██╔╝  
██║██║     ██║        ██║   
╚═╝╚═╝     ╚═╝        ╚═╝
*/

/*
Turn on query plans!
*/

/*

This doesn't work one bit.

Control flow logic works fine logically,
but the optimizer compiles a plan for everything,
even branches that don't run.

*/
CREATE OR ALTER PROCEDURE 
    dbo.YourMom 
(
    @Reputation int
)
AS 
BEGIN
SET NOCOUNT, XACT_ABORT ON;

SET STATISTICS XML ON;  

    IF @Reputation = 1
    BEGIN
        SELECT 
            u.Id, 
            u.DisplayName, 
            u.Reputation, 
            u.CreationDate
        FROM dbo.Users AS u
        WHERE u.Reputation = @Reputation;
    END;

    IF @Reputation > 1
    BEGIN
        SELECT 
            u.Id, 
            u.DisplayName, 
            u.Reputation, 
            u.CreationDate
        FROM dbo.Users AS u
        WHERE u.Reputation = @Reputation;
    END;

SET STATISTICS XML OFF; 

END;
GO 


/*Compare plans here*/
/*Look at compile and runtime values.*/
EXEC dbo.YourMom 
    @Reputation = 1;
GO 
/*And here*/
EXEC dbo.YourMom 
    @Reputation = 2;
GO 

/*Recompiles and go backwards. What changes?*/
EXEC sys.sp_recompile 
    @objname = 'dbo.YourMom';
GO

/*Look at compile and runtime values.*/
EXEC dbo.YourMom 
    @Reputation = 2;
GO 
/*And here*/
EXEC dbo.YourMom 
    @Reputation = 1;
GO 






/*We already have this index called your mom*/
CREATE INDEX 
    yourmom 
ON dbo.Users 
    (Reputation) 
INCLUDE 
    (Id, DisplayName);
GO

/*
Last I heard...
*/
CREATE OR ALTER PROCEDURE 
    dbo.YourMom 
(
    @Reputation int
)
AS 
BEGIN
SET NOCOUNT, XACT_ABORT ON;

SET STATISTICS XML ON;  

    IF @Reputation = 1
    BEGIN
        SELECT 
            u.Id, 
            u.DisplayName, 
            u.Reputation, 
            u.CreationDate
        FROM dbo.Users AS u WITH (INDEX = PK_Users_Id)
        /*In this branch, we'll hint the clustered index, which does exist*/
        WHERE u.Reputation = @Reputation;
    END;

    IF @Reputation > 1
    BEGIN
        SELECT 
            u.Id, 
            u.DisplayName, 
            u.Reputation, 
            u.CreationDate
        FROM dbo.Users AS u WITH (INDEX = yourdad) 
        /*In this branch, we'll try to force an index called yourdad that doesn't exist*/
        WHERE u.Reputation = @Reputation;
    END;

SET STATISTICS XML OFF; 

END;
GO 

/*What happens here?*/
/*1 shouldn't touch the branch with a bad index hint.*/
EXEC dbo.YourMom 
    @Reputation = 1;
GO 


/*No such index, whatever*/
SELECT i.name,
       i.type
FROM sys.indexes AS i 
WHERE i.object_id = OBJECT_ID('dbo.Users');






































/*If we change the name of the index, it's fine...*/
EXEC sys.sp_rename 
    @objname = N'dbo.Users.yourmom', 
    @newname = N'yourdad', 
    @objtype = N'INDEX';
GO 

/*Compare estimates here*/
EXEC dbo.YourMom 
    @Reputation = 1;
GO 
/*And here*/
EXEC dbo.YourMom 
    @Reputation = 2;
GO 

/*Recompiles and go backwards. What changes?*/
EXEC sys.sp_recompile 
    @objname = 'dbo.YourMom';
GO

 /*Compare estimates here*/
EXEC dbo.YourMom 
    @Reputation = 2;
GO 
/*And here*/
EXEC dbo.YourMom 
    @Reputation = 1;
GO    




























/*We could do this, or two *different* stored procedures*/
/*e.g. dbo.YourMom_RepOne and dbo.YourMom_RepOverOne*/

CREATE OR ALTER PROCEDURE 
    dbo.YourMom 
( 
    @Reputation int 
)
AS
    BEGIN
    SET NOCOUNT, XACT_ABORT ON;
        
        DECLARE 
            @sql nvarchar(MAX) = N'';

        SET @sql += N'
        /*dbo.YourMom*/
        SELECT 
            u.Id, 
            u.DisplayName, 
            u.Reputation, 
            u.CreationDate
        FROM dbo.Users AS u ';
        IF @Reputation = 1
            BEGIN
                SET @sql += N'WITH (INDEX = PK_Users_Id)
        WHERE u.Reputation = @iReputation;';
            END;

        IF @Reputation > 1
            BEGIN
                SET @sql += N'WITH (INDEX = yourdad)
        WHERE u.Reputation = @iReputation;';
            END;

        RAISERROR(@sql, 0, 1) WITH NOWAIT;
        
        SET STATISTICS XML ON; 
        
            EXEC sys.sp_executesql 
                @sql, 
              N'@iReputation int', 
                @Reputation;

        SET STATISTICS XML OFF;  
    
    END;
GO

/*Now we get correct estimates for both 1 & 2*/
EXEC dbo.YourMom 
    @Reputation = 1;
GO 
/*And different plans for both 1 & 2*/
EXEC dbo.YourMom 
    @Reputation = 2;
GO 
/*But parameters in this plan would be sniffed...*/
EXEC dbo.YourMom 
    @Reputation = 11;
GO     


/*This might be okay here, though*/
SELECT TOP (10) 
    u.Reputation, 
    records = FORMAT(COUNT_BIG(*), 'N0')
FROM dbo.Users AS u
GROUP BY u.Reputation
ORDER BY COUNT_BIG(*) DESC;
    

/*

IF branching goes well with:
 * Controlling flow of logic

IF branching pairs poorly with:
 * Performance
 * Getting different execution plans

*/