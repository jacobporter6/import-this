﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
GO 

CREATE INDEX 
    grmpf 
ON dbo.Posts
    (ParentId, OwnerUserId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 


/*
 ██████╗ ██████╗ ████████╗██╗ ██████╗ ███╗   ██╗ █████╗ ██╗            
██╔═══██╗██╔══██╗╚══██╔══╝██║██╔═══██╗████╗  ██║██╔══██╗██║            
██║   ██║██████╔╝   ██║   ██║██║   ██║██╔██╗ ██║███████║██║            
██║   ██║██╔═══╝    ██║   ██║██║   ██║██║╚██╗██║██╔══██║██║            
╚██████╔╝██║        ██║   ██║╚██████╔╝██║ ╚████║██║  ██║███████╗       
 ╚═════╝ ╚═╝        ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝       
                                                                       
██████╗ ███████╗ ██████╗ ██████╗ ███╗   ███╗██████╗ ██╗██╗     ███████╗
██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗ ████║██╔══██╗██║██║     ██╔════╝
██████╔╝█████╗  ██║     ██║   ██║██╔████╔██║██████╔╝██║██║     █████╗  
██╔══██╗██╔══╝  ██║     ██║   ██║██║╚██╔╝██║██╔═══╝ ██║██║     ██╔══╝  
██║  ██║███████╗╚██████╗╚██████╔╝██║ ╚═╝ ██║██║     ██║███████╗███████╗
╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚═╝     ╚═╝╚══════╝╚══════╝
*/


/*
We have a perfectly good stored procedure
*/
CREATE OR ALTER PROCEDURE 
    dbo.OptionalRecompile
(
    @ParentId int
)
AS
BEGIN
SET NOCOUNT, XACT_ABORT ON;

SET STATISTICS XML ON;

    SELECT TOP (10) 
        u.DisplayName, 
        p.*
    FROM dbo.Posts AS p
    JOIN dbo.Users AS u
        ON p.OwnerUserId = u.Id
    WHERE p.ParentId = @ParentId
    ORDER BY u.Reputation DESC;

SET STATISTICS XML OFF;

END;
GO

/*
That sometimes goes perfectly bad when things get run in a funny order
*/

EXEC dbo.OptionalRecompile 
    @ParentId = 184618;

EXEC dbo.OptionalRecompile 
    @ParentId = 0;


/*

Would fixing the key lookup help?

Is fixing the key lookup even reasonable?

*/













/*
"Index for selectivity", they said.
*/
SELECT TOP (10)
    p.ParentId,
    records = FORMAT(COUNT_BIG(*), 'N0')
FROM dbo.Posts AS p
GROUP BY p.ParentId
ORDER BY COUNT_BIG(*) DESC;
GO 













/*
We could recompile every single time, but...
*/
CREATE OR ALTER PROCEDURE 
    dbo.OptionalRecompile
(
    @ParentId int
)
AS
BEGIN
SET NOCOUNT, XACT_ABORT ON;

SET STATISTICS XML ON;

    SELECT TOP (10)
        u.DisplayName, 
        p.*
    FROM dbo.Posts AS p
    JOIN dbo.Users AS u
        ON p.OwnerUserId = u.Id
    WHERE p.ParentId = @ParentId
    ORDER BY u.Reputation DESC
    OPTION(RECOMPILE);

SET STATISTICS XML OFF;

END;
GO



EXEC dbo.OptionalRecompile 
    @ParentId = 184618;

EXEC dbo.OptionalRecompile 
    @ParentId = 0;
GO








/*
What if this gets called a lot?
*/
CREATE OR ALTER PROCEDURE 
    dbo.OptionalRecompile
(
    @ParentId int
)
AS
BEGIN
SET NOCOUNT, XACT_ABORT ON;

    SELECT TOP (10)
        u.DisplayName, 
        p.*
    FROM dbo.Posts AS p
    JOIN dbo.Users AS u
        ON p.OwnerUserId = u.Id
    WHERE p.ParentId = @ParentId
    ORDER BY u.Reputation DESC
    OPTION(RECOMPILE);

END;
GO



/*
--Laptop
ostress -SNADABRUTO\SQL2019 -d"StackOverflow2013" -Q"EXEC dbo.OptionalRecompile @ParentId = 184618;" -U"ostress" -P"ostress" -q -n100 -r20 -o"C:\temp\crap"

--VM
ostress -SSQL2019 -d"StackOverflow2013" -Q"EXEC dbo.OptionalRecompile @ParentId = 184618;" -U"ostress" -P"ostress" -q -n350 -r50 -o"C:\temp\crap"
*/













/*

Better idea:
 * Use dynamic SQL to only recompile sometimes.

*/
CREATE OR ALTER PROCEDURE 
    dbo.OptionalRecompile
(
    @ParentId int
)
AS
BEGIN
SET NOCOUNT, XACT_ABORT ON;

    DECLARE 
        @sql nvarchar(MAX) = N'';
    
    SET @sql += N'
        SELECT TOP (10)
            u.DisplayName, 
            p.*
        /*dbo.OptionalRecompile*/
        FROM dbo.Posts AS p
        JOIN dbo.Users AS u
            ON p.OwnerUserId = u.Id
        WHERE p.ParentId = @iParentId
        ORDER BY u.Reputation DESC';
    IF @ParentId = 0    
    BEGIN
    SET @sql += N'
        OPTION(RECOMPILE);';
    END;
ELSE
BEGIN
    --We're so tidy.
    SET @sql += N';';
END;

    EXEC sys.sp_executesql 
        @sql, 
      N'@iParentId int', 
        @iParentId = @ParentId;

END;
GO

--How we doin?
EXEC dbo.OptionalRecompile 
    @ParentId = 184618;

EXEC dbo.OptionalRecompile 
    @ParentId = 0;




/*
Remember: Anything *other than zero* will be fine.
*/
SELECT TOP (1000)
    p.ParentId,
    records = FORMAT(COUNT_BIG(*), 'N0')
FROM dbo.Posts AS p
GROUP BY p.ParentId
ORDER BY COUNT_BIG(*) DESC;
GO 


/*

Problems this pattern solves:
 * Searches for 0 recompile and use a new plan
 * Searches for everything else cache and reuse plans

Problems this pattern doesn’t solve:
 * Plan cache history will be limited
 * Less useful when problem values are unknown

I have a whole talk on this:
 * https://www.erikdarlingdata.com/sql-server/defeating-parameter-sniffing-with-dynamic-sql/
 * Like and subscripe

*/
