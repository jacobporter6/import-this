﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
GO 


/*
 ██████╗ ██████╗ ████████╗██╗███╗   ███╗██╗███████╗███████╗
██╔═══██╗██╔══██╗╚══██╔══╝██║████╗ ████║██║╚══███╔╝██╔════╝
██║   ██║██████╔╝   ██║   ██║██╔████╔██║██║  ███╔╝ █████╗  
██║   ██║██╔═══╝    ██║   ██║██║╚██╔╝██║██║ ███╔╝  ██╔══╝  
╚██████╔╝██║        ██║   ██║██║ ╚═╝ ██║██║███████╗███████╗
 ╚═════╝ ╚═╝        ╚═╝   ╚═╝╚═╝     ╚═╝╚═╝╚══════╝╚══════╝
                                                           
███████╗ ██████╗ ██████╗     ██╗   ██╗ ██████╗ ██╗   ██╗   
██╔════╝██╔═══██╗██╔══██╗    ╚██╗ ██╔╝██╔═══██╗██║   ██║   
█████╗  ██║   ██║██████╔╝     ╚████╔╝ ██║   ██║██║   ██║   
██╔══╝  ██║   ██║██╔══██╗      ╚██╔╝  ██║   ██║██║   ██║   
██║     ╚██████╔╝██║  ██║       ██║   ╚██████╔╝╚██████╔╝   
╚═╝      ╚═════╝ ╚═╝  ╚═╝       ╚═╝    ╚═════╝  ╚═════╝                                                                                              
*/


/*
Pay no attention to the binary string.
*/
DECLARE 
    @x varchar(180) = 0x4946204558495354530D0A280D0A53454C45435420312F300D0A46524F4D207379732E636F6C756D6E7320415320630D0A574845524520632E6F626A6563745F6964203D204F424A4543545F49442827506F73747327290D0A414E4420632E6E616D65203D202754686544696666270D0A290D0A424547494E0D0A414C544552205441424C452064626F2E506F7374730D0A2020202044524F5020434F4C554D4E20546865446966663B0D0A454E44;

EXECUTE (@x);
GO 


ALTER TABLE 
    dbo.Posts 
ADD 
    TheDiff AS DATEDIFF
               (
                   YEAR, 
                   CreationDate, 
                   LastActivityDate
               );
GO 

/*3*/
CREATE INDEX 
    noiceR
ON dbo.Posts
    (OwnerUserId, TheDiff) 
INCLUDE 
    (Score, PostTypeId)
WHERE 
    (PostTypeId = 1) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO

--OUR OLD FRIEND!
CREATE OR ALTER PROCEDURE 
    dbo.OptimizeForYou (@Gap int)
AS 
SET NOCOUNT, XACT_ABORT ON;
BEGIN

SET STATISTICS XML ON;

    SELECT TOP (500) 
        u.Id,
        u.DisplayName, 
        p.Score,
        p.AnswerCount
    FROM dbo.Posts AS p
    JOIN dbo.Users AS u
        ON u.Id = p.OwnerUserId
    WHERE DATEDIFF(YEAR, p.CreationDate, p.LastActivityDate) > @Gap
    AND   p.PostTypeId = 1
    ORDER BY p.Score DESC;

SET STATISTICS XML OFF;

END;
GO 

--Just in case
EXEC sys.sp_recompile 
    @objname = N'dbo.OptimizeForYou';

--This is fast, and a good plan
EXEC dbo.OptimizeForYou 
    @Gap = 9;

--This slows down a bit, but probably isn't the worst idea
EXEC dbo.OptimizeForYou 
    @Gap = 5;

--This goes poorly
EXEC dbo.OptimizeForYou 
    @Gap = 0;



--Have you tried restarting it?
EXEC sys.sp_recompile 
    @objname = N'dbo.OptimizeForYou';

--This is better for 0, but...
EXEC dbo.OptimizeForYou 
    @Gap = 0;

--Dammit, Janet
EXEC dbo.OptimizeForYou 
    @Gap = 5;

--DAMMIT, JANET
EXEC dbo.OptimizeForYou 
    @Gap = 9;
GO 

/*

Exploratory, from small to big:
 * Which index is used?
 * What's that filter doing?

*/















--Use dynamic SQL to optimize for specific values
CREATE OR ALTER PROCEDURE 
    dbo.OptimizeForYou 
(
    @Gap int
)
AS 
SET NOCOUNT, XACT_ABORT ON;
BEGIN

DECLARE 
    @sql nvarchar(MAX) = N'';

SET @sql += N'
    SELECT TOP (500) 
    /*dbo.OptimizeForYou*/
        u.Id,
        u.DisplayName, 
        p.Score,
        p.AnswerCount
    FROM dbo.Posts AS p
    JOIN dbo.Users AS u
        ON u.Id = p.OwnerUserId
    WHERE DATEDIFF(YEAR, p.CreationDate, p.LastActivityDate) > @iGap
    AND   p.PostTypeId = 1
    ORDER BY p.Score DESC
    OPTION(OPTIMIZE FOR(@iGap = [@@@]));
' + NCHAR(10);

SET @sql = 
    REPLACE
    (
        @sql, 
        N'[@@@]', 
        @Gap
    );

RAISERROR(@sql, 0, 1) WITH NOWAIT;

SET STATISTICS XML ON;

    EXECUTE sys.sp_executesql
        @sql,
      N'@iGap int',
        @Gap;

SET STATISTICS XML OFF;

END;
GO 


EXEC dbo.OptimizeForYou @Gap = 0;
EXEC dbo.OptimizeForYou @Gap = 5;
EXEC dbo.OptimizeForYou @Gap = 9;




/*
    Plan reuse?
*/
DBCC FREEPROCCACHE;
GO 
EXEC dbo.OptimizeForYou @Gap = 0;
GO 3
EXEC dbo.OptimizeForYou @Gap = 5;
GO 3
EXEC dbo.OptimizeForYou @Gap = 9;
GO 3

/*firstresponderkit.org*/
EXEC dbo.sp_BlitzCache 
    @DatabaseName = 'StackOverflow2013', 
    @MinimumExecutionCount = 3, 
    @SkipAnalysis = 1;





EXEC dbo.DropIndexes;

ALTER TABLE dbo.Posts
    DROP COLUMN TheDiff;

/*

Problems this pattern solves:
 * Plan reuse is bad, and we don’t have a “bad guy”
 * We want individual plans to reuse their plans

Problems this pattern doesn’t solve:
 * You can end up with a lot of different plans cached
 * If multiple parameters result in plan variance

*/