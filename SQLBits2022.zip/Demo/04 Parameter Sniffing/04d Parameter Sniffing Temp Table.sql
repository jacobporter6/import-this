﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
GO 

CREATE INDEX 
    igno
ON dbo.Posts 
    (OwnerUserId, PostTypeId)
WHERE 
    (PostTypeId = 1)
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    rant
ON dbo.Votes 
    (VoteTypeId, UserId, PostId)
INCLUDE 
    (BountyAmount, CreationDate) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
 
CREATE INDEX 
    clown 
ON dbo.Badges
    (UserId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 


/*
████████╗███████╗███╗   ███╗██████╗      
╚══██╔══╝██╔════╝████╗ ████║██╔══██╗     
   ██║   █████╗  ██╔████╔██║██████╔╝     
   ██║   ██╔══╝  ██║╚██╔╝██║██╔═══╝      
   ██║   ███████╗██║ ╚═╝ ██║██║          
   ╚═╝   ╚══════╝╚═╝     ╚═╝╚═╝          
                                         
████████╗ █████╗ ██████╗ ██╗     ███████╗
╚══██╔══╝██╔══██╗██╔══██╗██║     ██╔════╝
   ██║   ███████║██████╔╝██║     █████╗  
   ██║   ██╔══██║██╔══██╗██║     ██╔══╝  
   ██║   ██║  ██║██████╔╝███████╗███████╗
   ╚═╝   ╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝
*/





CREATE OR ALTER PROCEDURE 
   dbo.VoteSniffing
(
    @VoteTypeId int 
)
AS
SET XACT_ABORT, NOCOUNT ON;

    BEGIN
    
    SET STATISTICS XML ON;

        SELECT   
            UserId = 
                ISNULL(v.UserId, 0),
            Votes2013 = 
                SUM
                (
                    CASE 
                        WHEN (v.CreationDate >= '20130101'
                              AND v.CreationDate < '20140101')
                        THEN 1
                        ELSE 0
                    END
                ),
            TotalBounty = 
                SUM
                (
                    CASE 
                        WHEN v.BountyAmount IS NULL
                        THEN 0
                        ELSE 1
                    END
                ),
            PostCount = 
                COUNT(DISTINCT v.PostId),
            VoteTypeId = 
                @VoteTypeId
        FROM     dbo.Votes AS v
        WHERE    v.VoteTypeId = @VoteTypeId
        AND      NOT EXISTS
                 (   
                     SELECT 
                         1/0
                     FROM dbo.Posts AS p
                     JOIN dbo.Badges AS b 
                         ON b.UserId = p.OwnerUserId 
                     WHERE  p.OwnerUserId = v.UserId
                     AND    p.PostTypeId = 1 
                 )
        GROUP BY v.UserId;

    SET STATISTICS XML OFF;

    END;
GO

/*
Don't run this, just look at the saved query plans
*/

/*Slow*/
EXEC dbo.VoteSniffing @VoteTypeId = 1 WITH RECOMPILE;
EXEC dbo.VoteSniffing @VoteTypeId = 2 WITH RECOMPILE;
EXEC dbo.VoteSniffing @VoteTypeId = 3 WITH RECOMPILE;
EXEC dbo.VoteSniffing @VoteTypeId = 5 WITH RECOMPILE;
EXEC dbo.VoteSniffing @VoteTypeId = 6 WITH RECOMPILE;
EXEC dbo.VoteSniffing @VoteTypeId = 10 WITH RECOMPILE;


/*Fast*/
/*1*/  EXEC dbo.VoteSniffing @VoteTypeId = 4 WITH RECOMPILE;
/*2*/  EXEC dbo.VoteSniffing @VoteTypeId = 7 WITH RECOMPILE;
/*3*/  EXEC dbo.VoteSniffing @VoteTypeId = 8 WITH RECOMPILE;
/*4*/  EXEC dbo.VoteSniffing @VoteTypeId = 9 WITH RECOMPILE;
/*5*/  EXEC dbo.VoteSniffing @VoteTypeId = 11 WITH RECOMPILE;
/*6*/  EXEC dbo.VoteSniffing @VoteTypeId = 12 WITH RECOMPILE;
/*7*/  EXEC dbo.VoteSniffing @VoteTypeId = 13 WITH RECOMPILE;
/*8*/  EXEC dbo.VoteSniffing @VoteTypeId = 14 WITH RECOMPILE;
/*9*/  EXEC dbo.VoteSniffing @VoteTypeId = 15 WITH RECOMPILE;
/*10*/ EXEC dbo.VoteSniffing @VoteTypeId = 16 WITH RECOMPILE;
GO 



/*This kinda sucks, going from small to big*/
EXEC sys.sp_recompile 
    @objname = N'dbo.VoteSniffing';

EXEC dbo.VoteSniffing 
    @VoteTypeId = 4; /*Fast! Just like before.*/

EXEC dbo.VoteSniffing 
    @VoteTypeId = 1; /*Well, it's better than 15 seconds.*/

/*This really sucks*/
EXEC sys.sp_recompile 
    @objname = N'dbo.VoteSniffing';

EXEC dbo.VoteSniffing 
    @VoteTypeId = 1; /*Runs for 17 seconds*/

EXEC dbo.VoteSniffing 
    @VoteTypeId = 4; /*Poor four takes 13 seconds*/
GO 

/*

Why so slow?
 * Look at join order, where is time spent?
 * Where is the WHERE clause applied?
 * Are there any bad estimates?

*/







/*A temp table can help!*/
CREATE OR ALTER PROCEDURE 
    dbo.VoteSniffing 
( 
    @VoteTypeId int 
)
AS
BEGIN
SET XACT_ABORT, NOCOUNT ON;

    CREATE TABLE 
        #votes
    (
        UserId int NULL UNIQUE CLUSTERED,
        Votes2013 int NOT NULL,
        TotalBounty int NOT NULL,
        PostCount int NOT NULL
    );

    SET STATISTICS XML ON;

    INSERT 
        #votes WITH (TABLOCKX)
    (
        UserId,
        Votes2013,
        TotalBounty,
        PostCount
    )
    SELECT 
        UserId = v.UserId,
        Votes2013 = 
           SUM
           (
               CASE 
                   WHEN (v.CreationDate >= '20130101'
                         AND  v.CreationDate < '20140101')
                   THEN 1
                   ELSE 0
               END
           ),
        TotalBounty = 
            SUM
            (
                CASE 
                    WHEN v.BountyAmount IS NULL
                    THEN 0
                    ELSE 1
                END
            ),
        PostCount = 
            COUNT(DISTINCT v.PostId)
    FROM dbo.Votes AS v /*WITH (PAGLOCK)*/
    WHERE v.VoteTypeId = @VoteTypeId
    GROUP BY v.UserId;

    SELECT
        UserId = 
            ISNULL(v.UserId, 0),
        v.Votes2013,
        v.TotalBounty,
        v.PostCount,
        VoteTypeId = 
            @VoteTypeId
    FROM #votes AS v
    WHERE NOT EXISTS
          (
              SELECT 
                  1/0
              FROM dbo.Posts AS p
              JOIN dbo.Badges AS b 
                  ON b.UserId = p.OwnerUserId 
              WHERE  p.OwnerUserId = v.UserId
              AND    p.PostTypeId = 1 
          )
    ORDER BY v.UserId;

    SET STATISTICS XML OFF;

END;
GO


/*This is fine*/
EXEC sys.sp_recompile 
    @objname = N'dbo.VoteSniffing';

EXEC dbo.VoteSniffing 
    @VoteTypeId = 4;

EXEC dbo.VoteSniffing 
    @VoteTypeId = 1;

/*This is, too*/
EXEC sys.sp_recompile 
    @objname = N'dbo.VoteSniffing';

EXEC dbo.VoteSniffing 
    @VoteTypeId = 1;

EXEC dbo.VoteSniffing 
    @VoteTypeId = 4;


/*

But why is the Seek speed so different?
 * Locking!
  * Exacerbated by parameter sniffing
  * Row locks, lock escalation, etc.
  * PAGLOCK, TABLOCK or NOLOCK hints to avoid
  * Read Comitted Snapshot Isolation or Snapshot Isolation will solve the problem

*/

/*

Problems this pattern solves:
 * We get stable performance from any execution
 * The parameter sniffed part of the query is fenced off
 * Less impact on more critical code paths

Problems this pattern doesn’t solve:
 * Large result sets dumped into temp tables can be bad
 * High frequency temp table usage can be painful
  * But SQL Server 2019 in-memory tempdb can help quite a bit

*/