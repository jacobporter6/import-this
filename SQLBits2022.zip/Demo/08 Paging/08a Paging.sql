﻿USE StackOverflow2013;
SET NOCOUNT ON; 
SET STATISTICS TIME, IO OFF; 
EXEC dbo.DropIndexes;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
GO


/*
██████╗  █████╗  ██████╗ ██╗███╗   ██╗ ██████╗ 
██╔══██╗██╔══██╗██╔════╝ ██║████╗  ██║██╔════╝ 
██████╔╝███████║██║  ███╗██║██╔██╗ ██║██║  ███╗
██╔═══╝ ██╔══██║██║   ██║██║██║╚██╗██║██║   ██║
██║     ██║  ██║╚██████╔╝██║██║ ╚████║╚██████╔╝
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═╝╚═╝  ╚═══╝ ╚═════╝      
*/


/*
Turn on query plans
*/


/*

There are three pretty simple options for writing paging queries.

They all have the same thing in common:
  * Select a narrow list of relational columns
  * Limit the number of rows to just what we want
  * Get a wider list of columns for only those rows

*/



/*

They're all pretty fast with sane numbers, using the Id column

Id is the primary key, so it's in index order for us, already

*/
DECLARE 
    @page_number int = 1,
    @page_size int = 100;

WITH 
    fetching AS 
( 
    SELECT 
        p.Id, 
        n = 
            ROW_NUMBER() OVER 
            ( 
                ORDER BY 
                    p.Id 
            )
    FROM dbo.Posts AS p 
)
SELECT 
    p.*
FROM fetching AS f
JOIN dbo.Posts AS p
    ON f.Id = p.Id
WHERE f.n > ((@page_number - 1) * @page_size)
AND   f.n < ((@page_number * @page_size) + 1)
ORDER BY p.Id
OPTION (RECOMPILE);
GO

DECLARE 
    @page_number int = 1,
    @page_size int = 100;

WITH 
    f /*etch*/ AS
(
    SELECT TOP (@page_number * @page_size)
        p.Id, 
        n =
            ROW_NUMBER() OVER 
            ( 
                ORDER BY 
                    p.Id 
            )
    FROM dbo.Posts AS p
    ORDER BY p.Id
),
    o /*ffset*/ AS
(
    SELECT TOP (@page_size)
        f.id
    FROM f
    WHERE f.n >= ((@page_number - 1) * @page_size)
    ORDER BY f.id
)
SELECT   
    p.*
FROM o
JOIN dbo.Posts AS p
    ON o.id = p.Id
ORDER BY p.Id
OPTION (RECOMPILE);
GO

DECLARE 
    @page_number int = 1,
    @page_size int = 100;

WITH 
    paging AS
(
    SELECT 
        p.Id
    FROM dbo.Posts AS p
    ORDER BY p.Id 
    OFFSET ((@page_number - 1) * @page_size) 
    ROW FETCH NEXT (@page_size) ROWS ONLY
)
SELECT 
    p.*
FROM paging AS pg
JOIN dbo.Posts AS p
    ON pg.id = p.Id
ORDER BY p.Id
OPTION (RECOMPILE);
GO







/*
But when you go in deep, things can get slow.
*/

DECLARE 
    @page_number int = 1000000,
    @page_size int = 100;

WITH 
    paging AS
(
    SELECT 
        p.Id
    FROM dbo.Posts AS p
    ORDER BY p.Id 
    OFFSET ((@page_number - 1) * @page_size) 
    ROW FETCH NEXT (@page_size) ROWS ONLY
)
SELECT 
    p.*
FROM paging AS pg
JOIN dbo.Posts AS p
    ON pg.id = p.Id
ORDER BY p.Id
OPTION (RECOMPILE);
GO

































/*
What happens if we order by a different column first?

*/

/*Create this after looking at plans without it*/
CREATE INDEX 
    booty 
ON dbo.Posts 
    (LastActivityDate) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);


DECLARE 
    @page_number int = 1,
    @page_size int = 100;

WITH 
    fetching AS
(
    SELECT 
        p.Id, 
        n = 
            ROW_NUMBER() OVER 
            ( 
                ORDER BY /*Now we're ordering by LastActivityDate first*/
                    p.LastActivityDate, 
                    p.Id 
            )
    FROM dbo.Posts AS p
)
SELECT 
    p.*
FROM fetching AS f
JOIN dbo.Posts AS p
    ON f.Id = p.Id
WHERE f.n > ((@page_number - 1) * @page_size)
AND   f.n < ((@page_number * @page_size) + 1)
ORDER BY p.LastActivityDate
OPTION (RECOMPILE);
GO

DECLARE 
    @page_number int = 1,
    @page_size int = 100;

WITH 
    f/*etch*/ AS
(
    SELECT TOP (@page_number * @page_size)         
        p.Id, 
        p.LastActivityDate, 
        n = 
            ROW_NUMBER() OVER 
            ( 
                ORDER BY /*Now we're ordering by LastActivityDate first*/
                    p.LastActivityDate, 
                    p.Id 
            )
    FROM dbo.Posts AS p
    ORDER BY p.LastActivityDate
),
    o/*ffset*/ AS
(
    SELECT TOP (@page_size)
        f.id
    FROM f
    WHERE f.n >= ((@page_number - 1) * @page_size)
    ORDER BY f.LastActivityDate
)
SELECT 
    p.*
FROM o
JOIN dbo.Posts AS p
    ON o.id = p.Id
ORDER BY p.LastActivityDate
OPTION (RECOMPILE);
GO

DECLARE 
    @page_number int = 1,
    @page_size int = 100;

WITH 
    paging AS
(
    SELECT 
        p.Id
    FROM dbo.Posts AS p
    /*Now we're ordering by LastActivityDate first*/
    ORDER BY p.LastActivityDate, p.Id 
    OFFSET ((@page_number - 1) * @page_size) 
    ROW FETCH NEXT (@page_size) ROWS ONLY
)
SELECT 
    p.*
FROM paging AS pg
JOIN dbo.Posts AS p
    ON pg.id = p.Id
ORDER BY p.LastActivityDate
OPTION (RECOMPILE);
GO 



/*
Server side paging goes well with:
* Limiting the amount of data you're sending to app servers
* Predictable user query patterns


The only way to make paging reliably fast is with the right indexes
When you let users choose custom sort orders, indexing can become really complicated


Users probably want: 
* Custom where clauses
* Optional joins
* Count of total matching records

All of that can complicate indexing and querying

You may need to look into denormalized reporting tables, or specialized data stores like Elasticsearch

Pablo Blanco:
 * https://www.sqlservercentral.com/articles/optimising-server-side-paging-part-i
 * https://www.sqlservercentral.com/articles/optimising-server-side-paging-part-ii

*/
