﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
DBCC FREEPROCCACHE;
GO


/*
██████╗  █████╗  ██████╗ ██╗███╗   ██╗ ██████╗ 
██╔══██╗██╔══██╗██╔════╝ ██║████╗  ██║██╔════╝ 
██████╔╝███████║██║  ███╗██║██╔██╗ ██║██║  ███╗
██╔═══╝ ██╔══██║██║   ██║██║██║╚██╗██║██║   ██║
██║     ██║  ██║╚██████╔╝██║██║ ╚████║╚██████╔╝
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═╝╚═╝  ╚═══╝ ╚═════╝                                                
*/



CREATE OR ALTER PROCEDURE 
    dbo.AwesomePagingProcedure 
( 
    @OwnerUserId int = NULL,
    @CreationDate datetime = NULL,
    @LastActivityDate datetime = NULL,
    @PostTypeId int = NULL,
    @Score int = NULL,
    @Title nvarchar(250) = NULL,
    @Body nvarchar(MAX) = NULL,
    @page_number int = 1,
    @page_size int = 100,
    @order_col sysname = N'Id',
    @order_dir nchar(1) = N'A' 
)
AS
SET NOCOUNT, XACT_ABORT ON;

BEGIN

DECLARE 
    @SQLString nvarchar(MAX) = N'',
    @Filter nvarchar(MAX) = N'',
    @nl nchar(2) = NCHAR(10);

/*

I'm leaving out a lot of NULL checking, etc. 

IRL you'd wanna make sure some parameters have valid values before carrying on.

Brevity is a gift.

*/

IF @order_col 
    NOT IN 
(
    N'OwnerUserId', 
    N'CreationDate', 
    N'LastActivityDate', 
    N'PostTypeId',  
    N'Score', 
    N'Id'
)
BEGIN
  RAISERROR(N'That there column ain''t allowed, pardner, GIDDYUP!', 1, 0) WITH NOWAIT;
  RETURN;
END;

SET @SQLString += N'
/*dbo.AwesomePagingProcedure*/
WITH 
    fetching AS 
( 
    SELECT 
        p.Id, 
        n = 
            ROW_NUMBER() OVER 
            ( 
                ORDER BY 
                    p.' 
+ QUOTENAME(@order_col) 
+ CASE WHEN @order_dir = N'A' THEN N' ASC '
       WHEN @order_dir = N'D' THEN N' DESC '
       ELSE N', NEWID() DESC' /*Ha ha ha, don't actually do this.*/  
  END                          
+ N'        
            )                   
FROM dbo.Posts AS p
WHERE 1 = 1 ';

/*Check on filter conditions...*/
IF @OwnerUserId IS NOT NULL
   SET @Filter = @Filter + @nl + N'AND p.OwnerUserId = @iOwnerUserId';
IF @CreationDate IS NOT NULL
   SET @Filter = @Filter + @nl + N'AND p.CreationDate >= @iCreationDate';
IF @LastActivityDate IS NOT NULL
   SET @Filter = @Filter + @nl + N'AND p.LastActivityDate < @iLastActivityDate';
IF @Score IS NOT NULL
   SET @Filter = @Filter + @nl + N'AND p.Score >= @iScore'; 
IF @PostTypeId IS NOT NULL
   SET @Filter = @Filter + @nl + N'AND p.PostTypeId = @iPostTypeId';
IF @Title IS NOT NULL 
   SET @Filter = @Filter + @nl + N'AND p.Title LIKE ''%'' + @iTitle + ''%'' ';
IF @Body IS NOT NULL
   SET @Filter = @Filter + @nl + N'AND p.Body LIKE ''%'' + @iBody + ''%'' ';

/*Did we come up with anything?*/
IF @Filter IS NOT NULL
   SET @SQLString += @Filter;

/*Get the last stuff and filter the string columns*/
SET @SQLString += N'
)
SELECT 
    p.*
FROM fetching AS f
JOIN dbo.Posts AS p
    ON f.Id = p.Id
WHERE f.n > ((@ipage_number - 1) * @ipage_size)
AND   f.n < ((@ipage_number * @ipage_size) + 1) 
ORDER BY f.n;';


PRINT @SQLString;

EXEC sys.sp_executesql 
    @SQLString,
  N'@iOwnerUserId int, 
    @iCreationDate datetime, 
    @iLastActivityDate datetime, 
    @iPostTypeId int,
    @iScore int,
    @iTitle nvarchar(250),
    @iBody nvarchar(MAX),
    @ipage_number int,
    @ipage_size int',
    @OwnerUserId,
    @CreationDate,
    @LastActivityDate,
    @PostTypeId,
    @Score,
    @Title,
    @Body,
    @page_number,
    @page_size;

END;
GO 



/*

Turn on query plans, dummy!

*/


DBCC FREEPROCCACHE;
GO 

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = NULL,
    @CreationDate = '2013-06-01',
    @LastActivityDate = NULL,
    @PostTypeId = NULL,
    @Score = NULL,
    @Body = NULL,
    @Title = NULL,
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'LastActivityDate',
    @order_dir = N'A';

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = NULL,
    @CreationDate = NULL,
    @LastActivityDate = '2013-06-01',
    @PostTypeId = NULL,
    @Score = 5,
    @Body = NULL,
    @Title = NULL,
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'CreationDate',
    @order_dir = N'D';

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = 1,
    @CreationDate = NULL,
    @LastActivityDate = NULL,
    @PostTypeId = 2,
    @Score = NULL,
    @Body = NULL,
    @Title = NULL,
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'Score',
    @order_dir = N'D';

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = NULL,
    @CreationDate = '20080101',
    @LastActivityDate = '20090101',
    @PostTypeId = 2,
    @Score = 1,
    @Body = NULL,
    @Title = NULL,
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'OwnerUserId',
    @order_dir = N'A';

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = NULL,
    @CreationDate = NULL,
    @LastActivityDate = NULL,
    @PostTypeId = 2,
    @Score = 5,
    @Body = NULL,
    @Title = NULL,
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'OwnerUserId',
    @order_dir = N'D';




/*

But how do we index for all these?

*/

EXEC dbo.sp_BlitzCache 
    @DatabaseName = 'StackOverflow2013';



/*
  * Equality?
  * Order By?
  * Inequality?
  * Key columns? 
  * Includes?
  * Something else?
*/

















































/*
How much would you pay for an index that made them all fast?
*/


































/*
In a row store index, column order matters

Remember the sorting demos?
 * Equality predicates
 * Inequality predicates

*/

CREATE INDEX 
    codependent
ON dbo.Posts
(
    OwnerUserId, 
    /*^Depends On^*/
    Score, 
    /*^Depends On^*/
    CreationDate, 
    /*^Depends On^*/
    LastActivityDate, 
    /*^Depends On^*/
    PostTypeId,
    /*^Depends On^*/
    Id
)
INCLUDE
    (Title) 
/*^Doesn't depend on anything. It's an Include.^*/
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);







































/*
Pls be SQL Server 2012+
*/
EXEC dbo.DropIndexes;
GO 
CREATE NONCLUSTERED COLUMNSTORE INDEX 
    nodependent 
ON dbo.Posts
    (OwnerUserId, Score, CreationDate, LastActivityDate, PostTypeId, Id, Title)
WITH(MAXDOP = 1);
/*
In real life I'd probably want to stick all the columns I can in this index.
Here, I'm just indexing the columns I'm searching on because it creates faster.

Column store indexes:
 * Store and compress each column individually
  * No ordering dependency
 * Column can be searched and selected individuallu
 * Allows for Batch Mode processing
  * Rows are processed in groups of up to 900 (depending on size)
  * CPU instructions are run on each batch (SIMD)

Great for queries that:
 * Have unpredictable patterns, like these
 * Process lots of rows, which can be a CPU suck

*/
GO 








DBCC FREEPROCCACHE;
GO 

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = NULL,
    @CreationDate = '2013-06-01',
    @LastActivityDate = NULL,
    @PostTypeId = NULL,
    @Score = NULL,
    @Body = NULL,
    @Title = NULL,
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'LastActivityDate',
    @order_dir = N'A';

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = NULL,
    @CreationDate = NULL,
    @LastActivityDate = '2013-06-01',
    @PostTypeId = NULL,
    @Score = 5,
    @Body = NULL,
    @Title = NULL,
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'CreationDate',
    @order_dir = N'D';

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = 1,
    @CreationDate = NULL,
    @LastActivityDate = NULL,
    @PostTypeId = 2,
    @Score = NULL,
    @Body = NULL,
    @Title = NULL,
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'Score',
    @order_dir = N'D';

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = NULL,
    @CreationDate = '20080101',
    @LastActivityDate = '20090101',
    @PostTypeId = 2,
    @Score = 1,
    @Body = NULL,
    @Title = NULL,
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'OwnerUserId',
    @order_dir = N'A';

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = NULL,
    @CreationDate = NULL,
    @LastActivityDate = NULL,
    @PostTypeId = 2,
    @Score = 5,
    @Body = NULL,
    @Title = NULL,
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'OwnerUserId',
    @order_dir = N'D';




/*What about text filters?!*/

EXEC dbo.AwesomePagingProcedure 
    @OwnerUserId = NULL,
    @CreationDate = NULL,
    @LastActivityDate = NULL,
    @PostTypeId = 1,
    @Score = 5,
    @Body = N'SQL',
    @Title = N'SQL',
    @page_number = 1,
    @page_size = 1000,
    @order_col = N'LastActivityDate',
    @order_dir = N'D';



/*
DON'T FORGET TO DROP THIS INDEX YOU BIG DUMMY
DON'T FORGET TO DROP THIS INDEX YOU BIG DUMMY
DON'T FORGET TO DROP THIS INDEX YOU BIG DUMMY
DON'T FORGET TO DROP THIS INDEX YOU BIG DUMMY
*/

EXEC dbo.DropIndexes;

