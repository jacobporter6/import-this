﻿USE StackOverflow2013;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 150;
EXEC dbo.DropIndexes;

CREATE INDEX 
    ffffffuuuuuuu 
ON dbo.Posts
    (OwnerUserId, Score DESC, CreationDate, LastActivityDate)
INCLUDE
    (PostTypeId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 

/*
 ██████╗ ██████╗ ████████╗██╗ ██████╗ ███╗   ██╗ █████╗ ██╗                         
██╔═══██╗██╔══██╗╚══██╔══╝██║██╔═══██╗████╗  ██║██╔══██╗██║                         
██║   ██║██████╔╝   ██║   ██║██║   ██║██╔██╗ ██║███████║██║                         
██║   ██║██╔═══╝    ██║   ██║██║   ██║██║╚██╗██║██╔══██║██║                         
╚██████╔╝██║        ██║   ██║╚██████╔╝██║ ╚████║██║  ██║███████╗                    
 ╚═════╝ ╚═╝        ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝                    
                                                                                    
██████╗  █████╗ ██████╗  █████╗ ███╗   ███╗███████╗████████╗███████╗██████╗ ███████╗
██╔══██╗██╔══██╗██╔══██╗██╔══██╗████╗ ████║██╔════╝╚══██╔══╝██╔════╝██╔══██╗██╔════╝
██████╔╝███████║██████╔╝███████║██╔████╔██║█████╗     ██║   █████╗  ██████╔╝███████╗
██╔═══╝ ██╔══██║██╔══██╗██╔══██║██║╚██╔╝██║██╔══╝     ██║   ██╔══╝  ██╔══██╗╚════██║
██║     ██║  ██║██║  ██║██║  ██║██║ ╚═╝ ██║███████╗   ██║   ███████╗██║  ██║███████║
╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚══════╝                                                                                    
*/








/*
This is prone to all sorts of issues.
*/
CREATE OR ALTER PROCEDURE 
    dbo.AwesomeSearchProcedure 
(
    @OwnerUserId int = NULL, 
    @CreationDate datetime = NULL, 
    @LastActivityDate datetime = NULL,
    @PostTypeId int = NULL,
    @Score int = NULL,
    @Title nvarchar(250) = NULL, 
    @Body nvarchar(MAX) = NULL
)
AS
SET NOCOUNT, XACT_ABORT ON;
BEGIN    

    SELECT TOP (5000) 
        p.OwnerUserId,
        p.Score,
        Tags = 
            ISNULL(p.Tags, N'N/A: Question'),
        Title = 
            ISNULL(p.Title, N'N/A: Question'), 
        p.CreationDate, 
        p.LastActivityDate, 
        p.Body
    FROM dbo.Posts AS p
    WHERE  (p.OwnerUserId = @OwnerUserId OR @OwnerUserId IS NULL)
    AND    (p.CreationDate >= @CreationDate OR @CreationDate IS NULL)
    AND    (p.LastActivityDate < @LastActivityDate OR @LastActivityDate IS NULL)
    AND    (p.Score >= @Score OR @Score IS NULL)
    AND    (p.PostTypeId = @PostTypeId OR @PostTypeId IS NULL)
    AND    (p.Title LIKE N'%' + @Title + N'%' OR @Title IS NULL)
    AND    (p.Body LIKE N'%' + @Body + N'%' OR @Body IS NULL)
    ORDER BY p.Score DESC;

END;
GO     

/*

These run "fine" because our index leads with OwnerUserId 

But look at the index scan. That sucks.

🙄

*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 35004;
GO
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 22656;
GO
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 22656, 
    @Body = N'SQL';
GO

/*Don't run these, show the saved plans*/
EXEC dbo.AwesomeSearchProcedure 
    @CreationDate = '20130101', 
    @LastActivityDate = '20140101'; 
GO 
EXEC dbo.AwesomeSearchProcedure 
    @Title = N'SQL'; 
GO 

/*

Recompile and run in reverse order

Does that look like a good plan in general?

*/
EXEC sys.sp_recompile 
    @objname = N'dbo.AwesomeSearchProcedure';
GO 






















/*
Path of least resistance. Hit that recompile button.
*/
CREATE OR ALTER PROCEDURE 
    dbo.AwesomeSearchProcedure 
( 
    @OwnerUserId int = NULL, 
    @CreationDate datetime = NULL, 
    @LastActivityDate datetime = NULL,
    @PostTypeId int = NULL,
    @Score int = NULL,
    @Title nvarchar(250) = NULL, 
    @Body nvarchar(MAX) = NULL 
)
AS
SET NOCOUNT, XACT_ABORT ON;
BEGIN    

    SELECT TOP (5000) 
        p.OwnerUserId,
        p.Score,
        Tags = 
            ISNULL(p.Tags, N'N/A: Question'),
        Title = 
            ISNULL(p.Title, N'N/A: Question'), 
        p.CreationDate, 
        p.LastActivityDate, 
        p.Body
    FROM dbo.Posts AS p
    WHERE  (p.OwnerUserId = @OwnerUserId OR @OwnerUserId IS NULL)
    AND    (p.CreationDate >= @CreationDate OR @CreationDate IS NULL)
    AND    (p.LastActivityDate < @LastActivityDate OR @LastActivityDate IS NULL)
    AND    (p.Score >= @Score OR @Score IS NULL)
    AND    (p.PostTypeId = @PostTypeId OR @PostTypeId IS NULL)
    AND    (p.Title LIKE N'%' + @Title + N'%' OR @Title IS NULL)
    AND    (p.Body LIKE N'%' + @Body + N'%' OR @Body IS NULL)
    ORDER BY p.Score DESC
    OPTION(RECOMPILE);
    /*Recompiling will fix "most" problems, unless you run this frequently*/ 
    /*You'll still have a hell of a time indexing for it*/
END;
GO     

/*Still good*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 35004;
GO
/*Still good*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 22656;
GO
/*Okay searching Body will always kinda suck*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 22656, 
    @Body = N'SQL';
GO
/*NOPE THIS IS FINE NO INDEX COULD HELP*/
EXEC dbo.AwesomeSearchProcedure 
    @CreationDate = '20130101', 
    @LastActivityDate = '20140101'; 
GO 
/*This is also stupid*/
EXEC dbo.AwesomeSearchProcedure 
    @Title = N'SQL'; 
GO 


/*Stop here, dynamic SQL is next*/




























/*

This is the utterly wrong way to write dynamic SQL

If you do this, you're not gonna be happy.

*/

CREATE OR ALTER PROCEDURE 
    dbo.AwesomeSearchProcedure 
( 
    @OwnerUserId int = NULL, 
    @CreationDate datetime = NULL, 
    @LastActivityDate datetime = NULL,
    @PostTypeId int = NULL,
    @Score int = NULL,
    @Title nvarchar(250) = NULL, 
    @Body nvarchar(MAX) = NULL 
)
AS
SET NOCOUNT, XACT_ABORT ON;

BEGIN
    
DECLARE 
    @SQLString nvarchar(MAX) = N'',
    @Filter nvarchar(MAX) = N'',
    @nl nchar(2) = NCHAR(10);

SET @SQLString += N'
/*dbo.AwesomeSearchProcedure*/
SELECT TOP (5000) 
    p.OwnerUserId,
    p.Score,
    Tags = 
        ISNULL(p.Tags, N''N/A: Question''),
    Title = 
        ISNULL(p.Title, N''N/A: Question''), 
    p.CreationDate, 
    p.LastActivityDate, 
    p.Body
FROM dbo.Posts AS p
WHERE 1 = 1 ' + @nl;

IF @OwnerUserId IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.OwnerUserId = ' + RTRIM(@OwnerUserId) + @nl; END;

IF @CreationDate IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.CreationDate >= CONVERT(DATETIME, ''' + RTRIM(@CreationDate) + N''')' + @nl; END;

IF @LastActivityDate IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.LastActivityDate < CONVERT(DATETIME, ''' + RTRIM(@LastActivityDate) + N''')' + @nl; END;

IF @Score IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.Score = ' + RTRIM(@Score) + @nl; END; 

IF @PostTypeId IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.PostTypeId = ' + RTRIM(@PostTypeId) + @nl; END; 

IF @Title IS NOT NULL 
   BEGIN SET @Filter = @Filter + N'AND p.Title LIKE ''' + N'%' + @Title + N'%''' + @nl; END;

IF @Body IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.Body LIKE ''' + N'%' + @Body + N'%''' + @nl; END;

IF @Filter IS NOT NULL
   BEGIN SET @SQLString += @Filter; END;

SET @SQLString += N'ORDER BY p.Score DESC;';

PRINT @SQLString;
EXEC (@SQLString);

END;
GO 


/*Still good*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 35004;
GO
/*Still good*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 22656;
GO
/*Okay searching Body will always kinda suck*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 22656, 
    @Body = N'SQL Server';
GO
/*NOPE THIS IS FINE NO INDEX COULD HELP*/
EXEC dbo.AwesomeSearchProcedure 
    @CreationDate = '20130101', 
    @LastActivityDate = '20140101'; 
GO 
/*This is also stupid*/
EXEC dbo.AwesomeSearchProcedure 
    @Title = N'SQL Server'; 
GO 


/*

HAX !

Okay, look, most of these are "probably safe"
 * It's pretty hard to SQL inject numbers, dates, bits, etc.
 * Strings were a mistake, though.

*/



/*

Look in the Messages tab

*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 35004;

/*
I can explore sys.tables
*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 35004, 
    @Body = N''' UNION ALL 
                 SELECT t.object_id, 
                        t.schema_id, 
                        t.name, 
                        SCHEMA_NAME(t.schema_id),
                        t.create_date,
                        t.modify_date,
                        NULL
                 FROM sys.tables AS t --';
GO 



/*
I can explore sys.columns
*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 35004, 
    @Body = N''' UNION ALL 
                 SELECT c.object_id, 
                        c.column_id, 
                        c.name, 
                        OBJECT_NAME(c.object_id),
                        NULL,
                        NULL,
                        NULL
                 FROM sys.columns AS c 
                 WHERE c.object_id = OBJECT_ID(''dbo.HackMe'') --';
GO 

/*
I can explore the base table, and get information
*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 35004, 
    @Body = N'''  UNION ALL 
                  SELECT NULL,
                         hm.CustomerAcctNo,
                         hm.CustomerName, 
                         hm.CustomerSSN,
                         hm.CustomerDOB, 
                         NULL, 
                         NULL
                  FROM dbo.HackMe AS hm --';
GO     































/*
This is a good implementation.

Please do this if you have to.
*/

CREATE OR ALTER PROCEDURE 
    dbo.AwesomeSearchProcedure 
( 
    @OwnerUserId int = NULL, 
    @CreationDate datetime = NULL, 
    @LastActivityDate datetime = NULL,
    @PostTypeId int = NULL,
    @Score int = NULL,
    @Title nvarchar(250) = NULL, 
    @Body nvarchar(MAX) = NULL 
)
AS
SET NOCOUNT, XACT_ABORT ON;

BEGIN

/*TODO: Implement paging, or something.*/

DECLARE 
    @SQLString nvarchar(MAX) = N'',
    @Filter nvarchar(MAX) = N'',
    @nl nchar(2) = NCHAR(10);

SET @SQLString += N'
/*dbo.AwesomeSearchProcedure*/
SELECT TOP (5000) 
    p.OwnerUserId,
    p.Score,
    Tags = 
        ISNULL(p.Tags, N''N/A: Question''),
    Title = 
        ISNULL(p.Title, N''N/A: Question''), 
    p.CreationDate, 
    p.LastActivityDate, 
    p.Body
FROM dbo.Posts AS p
WHERE 1 = 1 ' + @nl;

IF @OwnerUserId IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.OwnerUserId = @iOwnerUserId ' + @nl; END;

IF @CreationDate IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.CreationDate >= @iCreationDate' + @nl; END;

IF @LastActivityDate IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.LastActivityDate < @iLastActivityDate' + @nl; END;

IF @Score IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.Score >= @iScore' + @nl; END;

IF @PostTypeId IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.PostTypeId = @iPostTypeId' + @nl; END;
   
IF @Title IS NOT NULL 
   BEGIN SET @Filter = @Filter + N'AND p.Title LIKE ''%'' + @iTitle + ''%'' ' + @nl; END;

IF @Body IS NOT NULL
   BEGIN SET @Filter = @Filter + N'AND p.Body LIKE ''%'' + @iBody + ''%'' ' + @nl; END;

IF @Filter IS NOT NULL
   SET @SQLString += @Filter;

SET @SQLString += N'ORDER BY p.Score DESC;';

PRINT @SQLString;
EXEC sys.sp_executesql 
    @SQLString,
  N'@iOwnerUserId int, 
    @iCreationDate datetime, 
    @iLastActivityDate datetime, 
    @iScore int,
    @iPostTypeId int,
    @iTitle nvarchar(250),
    @iBody nvarchar(MAX)',
    @OwnerUserId,
    @CreationDate,
    @LastActivityDate,
    @Score,
    @PostTypeId,
    @Title,
    @Body;

END;
GO 

/*

Look in the Messages tab

*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 35004, 
    @Body = N'''  UNION ALL 
                  SELECT NULL,
                         hm.CustomerAcctNo,
                         hm.CustomerName, 
                         hm.CustomerSSN,
                         hm.CustomerDOB, 
                         NULL, 
                         NULL 
                  FROM dbo.HackMe AS hm --';
GO 



/*Still good*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 35004;
GO
/*Still good*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 22656;
GO
/*Okay searching Body will always kinda suck*/
EXEC dbo.AwesomeSearchProcedure 
    @OwnerUserId = 22656, 
    @Body = N'SQL Server';
GO
/*NOPE THIS IS FINE NO INDEX COULD HELP*/
EXEC dbo.AwesomeSearchProcedure 
    @CreationDate = '20130101', 
    @LastActivityDate = '20140101'; 
GO 
/*This is also stupid*/
EXEC dbo.AwesomeSearchProcedure 
    @Title = N'SQL Server'; 
GO 

/*

What we have so far:
* A stored procedure that is reliably fast when we search on OwnerUserId
* Is fastER for Date and Title searches than before
* Is safe from SQL Injection

What we still need:
* To be able to page through results
* For this to be reliably fast for any filter

*/
