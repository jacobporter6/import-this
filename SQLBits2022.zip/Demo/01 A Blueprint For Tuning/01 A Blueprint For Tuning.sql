﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
SET NOCOUNT ON;
DBCC FREEPROCCACHE;
GO

/*
██████╗ ██╗     ██╗   ██╗███████╗██████╗ ██████╗ ██╗███╗   ██╗████████╗
██╔══██╗██║     ██║   ██║██╔════╝██╔══██╗██╔══██╗██║████╗  ██║╚══██╔══╝
██████╔╝██║     ██║   ██║█████╗  ██████╔╝██████╔╝██║██╔██╗ ██║   ██║   
██╔══██╗██║     ██║   ██║██╔══╝  ██╔═══╝ ██╔══██╗██║██║╚██╗██║   ██║   
██████╔╝███████╗╚██████╔╝███████╗██║     ██║  ██║██║██║ ╚████║   ██║   
╚═════╝ ╚══════╝ ╚═════╝ ╚══════╝╚═╝     ╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝   ╚═╝   
*/

/*
In a perfect world

We’d never have to deal with “slow” queries because:
 * Hardware is totally overworked and underpowered
 * Some process(es) went totally rogue on us
 * We’re blocked by someone trying to “fix” something
*/

    --Window 1
    BEGIN TRAN;
        UPDATE t
            SET t.MaxScore = 2147483647 
        FROM dbo.TotalScoreByUser AS t
        WHERE 'Oops' = 'Oops';
    
    ROLLBACK;
    
    --Window 2
    SELECT * FROM dbo.TotalScoreByUser AS tsbu;
    
    --Window 3
    EXEC dbo.sp_WhoIsActive;

/*
Not query tuning...

Yes, things are slow, and yes we have work to do
 * But that’s server tuning:
 * Adding memory
 * Adding CPU
 * Revoking someone’s access

When query and index tuning doesn’t work
 * Things get better for an individual query, but when it’s part of a larger workload, things are still bad

The server still has glaring issues:
 * THREADPOOL
 * RESOURCE_SEMAPHORE
 * Other physical bottlenecks in wait stats
*/


/*
Is it reproducible?
*/

SET STATISTICS XML ON;
DBCC DROPCLEANBUFFERS;
WAITFOR DELAY '00:00:01.000';
SELECT records = COUNT_BIG(*) FROM dbo.Posts AS p;
WAITFOR DELAY '00:00:01.000';
SELECT records = COUNT_BIG(*) FROM dbo.Posts AS p;
SET STATISTICS XML OFF;

/*
In order to reproduce and fix performance problems:

 * Query Plan (actual if possible)
 * Text (Parameter values, different sets if parameter sniffing)
 * Indexes
 * Parameters
*/

/*
When you're tuning a query:

Separation of duties
 * Informational vs. Relational columns

Clear predicates
 * Avoid non-SARGables, OR, CASE, etc. 

Adequate indexes
 * Indexes support what your query is doing

Manageable logic
 * That 5,000 line all-in-one query is probably a bad idea
*/

/*
Index choice
*/
CREATE INDEX 
    r 
ON dbo.Users 
    (Reputation) 
WITH(MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

SET STATISTICS XML ON;
SELECT 
    u.*
FROM dbo.Users AS u
WHERE u.Reputation = 11;

SELECT 
    u.Id, 
    u.Reputation
FROM dbo.Users AS u
WHERE u.Reputation = 11;
SET STATISTICS XML OFF;


/*
Memory
*/

SET STATISTICS XML ON;
SELECT 
    u.Id
FROM dbo.Users AS u
WHERE u.Reputation = 11
ORDER BY u.CreationDate DESC;

SELECT 
    u.*
FROM dbo.Users AS u
WHERE u.Reputation = 11
ORDER BY u.CreationDate DESC
OPTION(MAXDOP 1);
SET STATISTICS XML OFF;



/*
Avoid these things in general:
 * function(column) = something
 * column + column = something
 * column + value = something
 * column = @something or @something IS NULL
 * column like ‘%something’
 * column = case when …
*/

CREATE INDEX 
    d 
ON dbo.Users
    (DisplayName) 
WITH(MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    ud ON 
dbo.Users
    (UpVotes, DownVotes) 
WITH(MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

--Turn on query plans
SELECT records = COUNT(*) FROM dbo.Users AS u WHERE DATALENGTH(u.DisplayName) > 10;
SELECT records = COUNT(*) FROM dbo.Users AS u WHERE u.UpVotes + u.DownVotes = 1000;
SELECT records = COUNT(*) FROM dbo.Users AS u WHERE u.UpVotes + 1000 = 2000;
DECLARE @i int = 1; SELECT records = COUNT(*) FROM dbo.Users AS u WHERE u.UpVotes = @i OR @i IS NULL;
SELECT records = COUNT(*) FROM dbo.Users AS u WHERE u.DisplayName LIKE '%ZZZ';
SELECT records = COUNT(*) FROM dbo.Users AS u WHERE u.UpVotes = CASE WHEN u.DownVotes = 1 THEN 1 ELSE 0 END;


/*
Writing queries in this way can cause problems
 * Prevent otherwise possible index seeks
 * Poor cardinality estimates (fixed guess)
 * Increased CPU, unnecessary parallelism
 * Make missing index requests even worse than usual
 * UDFs may be touching other tables and not telling you about it in the query plan

Query data the way it's stored, Store data the way it's queried
*/

--Don't forget the estimated plan, bozo
SELECT TOP (1) 
    u.DisplayName, 
    dbo.ScalarFunction(u.Id)
FROM dbo.Users AS u
WHERE dbo.ScalarFunction(u.Id) > 475
ORDER BY u.Id;

/*
There are times when this won’t cause a big problem
But if you can avoid it, you should
It sets a bad example for others
Code is culture, and developers will take bad habits with them when they write new queries
It’s a lot harder to re-teach someone to do things the right way when they’ve been wrong for years

*/


/*
Implicit conversion is a SARGability problem, too
*/

DECLARE 
    @s sql_variant = N'1';

SELECT 
    records = COUNT(*)
FROM dbo.Votes AS v
WHERE v.Id = @s;



/*
Good indexes are ones that help queries
 * Find data: Your where clause
 * Relate data: Any joins
 * Order data: Not just order by; lots of things work better when ordering is supported by indexes

Notice I’m not mentioning included columns here!

*/


SELECT 
    p.*
FROM dbo.Posts AS p
WHERE p.ParentId = 1;


/*
That’s what your clustered index is for
 * Unless you can’t change the queries
 * And you can change the indexes

Don’t treat your nonclustered indexes like clustered indexes; you’ll eventually be unhappy with:
 * Modifications
 * Locking
 * Blocking
*/



/*
Totally Unscientific:
If a query is so long that it doesn’t all fit on one screen, it’s too long and needs to be broken up
 * Sometimes there are logical stopping points
 * * CTEs, Derived tables, Views
 * Other times you need to experiment with join order
*/


WITH 
    QuestionPostThing AS
(
    SELECT 
        p.Id, 
        p.OwnerUserId, 
        p.Score
    FROM StackOverflow2013_Clean.dbo.Posts AS p
    WHERE p.PostTypeId = 1 /*Questions*/
    AND   p.Score > 0 /*Positive Score*/
    AND   p.AcceptedAnswerId > 0 /*Accepted Answer*/
    AND   p.ClosedDate IS NULL /*Not Closed*/
    AND   p.CommunityOwnedDate IS NULL /*Not Community Owned*/
    AND   EXISTS 
          (
              SELECT 
                  1/0 
              FROM StackOverflow2013_Clean.dbo.Users AS u 
              WHERE u.Id = p.OwnerUserId 
              AND   u.Reputation >= 1000
          )
),
    AnswerPostThing AS 
(
    SELECT 
        p.Id, 
        p.OwnerUserId, 
        p.Score, 
        p.ParentId
    FROM StackOverflow2013_Clean.dbo.Posts AS p
    WHERE p.PostTypeId = 2 /*Aswers*/
    AND   p.Score > 0 /*Positive Score*/
    AND   p.CommunityOwnedDate IS NULL /*Not Community Owned*/
    AND   EXISTS 
          (
              SELECT 
                  1/0 
              FROM StackOverflow2013_Clean.dbo.Users AS u 
              WHERE u.Id = p.OwnerUserId 
              AND   u.Reputation >= 1000
          )
),
    NoSelfCollusion AS 
(
    SELECT 
        AnswerId = a.Id, 
        AnswerOwnerUserId = a.OwnerUserId, 
        AnswerScore = a.Score, 
        QuestionId = q.Id, 
        QuestionOwnerUserId = q.OwnerUserId, 
        QuestionScore = q.Score
    FROM AnswerPostThing AS a
    JOIN QuestionPostThing AS q
        ON  a.ParentId = q.id
        AND a.OwnerUserId <> q.OwnerUserId /*Not Self Answered!*/
),
    Bounties AS 
(
    SELECT 
        nc.AnswerId, 
        nc.AnswerOwnerUserId, 
        nc.AnswerScore, 
        nc.QuestionId, 
        nc.QuestionOwnerUserId, 
        nc.QuestionScore,
        v.BountyAmount
    FROM NoSelfCollusion AS nc
    JOIN StackOverflow2013_Clean.dbo.Votes AS v
        ON nc.AnswerId = v.PostId
        OR nc.QuestionId = v.PostId
    WHERE v.BountyAmount IS NOT NULL 
    /*Only interested in bountied questions*/
)
SELECT 
    u.Id, 
    u.DisplayName,
    QuestionScoreSum = 
        SUM(b.QuestionScoreSum),
    AnswerScoreSum = 
        SUM(b.AnswerScoreSum),
    BountySum = 
        SUM(b.BountySum),
    AnswerCommentScore = 
        SUM(b.AnswerCommentScore),
    QuestionCommentScore = 
        SUM(b.QuestionCommentScore) 
FROM StackOverflow2013_Clean.dbo.Users AS u
JOIN 
(
SELECT
    b.AnswerOwnerUserId,
    b.QuestionOwnerUserId,
    QuestionScoreSum = 
        SUM(b.QuestionScore * 1.0),
    AnswerScoreSum = 
        SUM(b.AnswerScore * 1.0),
    BountySum = 
        SUM(b.BountyAmount * 1.0),
    AnswerCommentScore = 
        (
            SELECT 
                SUM(c.Score) 
            FROM StackOverflow2013_Clean.dbo.Comments AS c 
            WHERE c.PostId = b.AnswerId
        ),
    QuestionCommentScore = 
        (
            SELECT 
                SUM(c.Score) 
            FROM StackOverflow2013_Clean.dbo.Comments AS c 
            WHERE c.PostId = b.QuestionId
        )
FROM Bounties AS b
GROUP BY 
    b.AnswerOwnerUserId, 
    b.QuestionOwnerUserId, 
    b.AnswerId, 
    b.QuestionId
) AS b
    ON u.Id = b.AnswerOwnerUserId
    OR u.Id = b.QuestionOwnerUserId
WHERE u.Reputation >= 1000
AND u.Id IN 
    (
        SELECT 
            b.UserId
        FROM dbo.Badges AS b
        WHERE b.Name IN 
              ( 
                  N'Nice Question',
                  N'Good Question', 
                  N'Great Question', 
                  N'Great Answer',
                  N'Nice Answer', 
                  N'Good Answer' 
              )
    )
GROUP BY 
    u.Id, 
    u.DisplayName;



/*
You may be able to write incredibly long queries that are also incredibly fast – it’s not impossible – just rare
Typically they involve a jumble of joins, and some wild where clauses that have been tacked on over the years
The more complexity you add, the more chance you have of the optimizer making a bad choice, or not exploring a good choice. 

It’s human, after all.

Remember:
 * Make sure you're tuning the right thing
 * Reproducibly slow queries!
 * Always check the server for nastiness
  * Threadpool, Resource Semaphore, Excessive Page IO Latch

Where to start:
 * Select list burdens
 * Implicit conversion
 * Non-SARGables
 * Functions
 * Missing indexes
 * Complexity
*/