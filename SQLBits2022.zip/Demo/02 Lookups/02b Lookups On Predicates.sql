﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
DBCC FREEPROCCACHE;

CREATE INDEX 
    whatever 
ON dbo.Comments 
    (Score, UserId, PostId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 

/*
██████╗ ██████╗ ███████╗██████╗ ██╗ ██████╗ █████╗ ████████╗███████╗
██╔══██╗██╔══██╗██╔════╝██╔══██╗██║██╔════╝██╔══██╗╚══██╔══╝██╔════╝
██████╔╝██████╔╝█████╗  ██║  ██║██║██║     ███████║   ██║   █████╗  
██╔═══╝ ██╔══██╗██╔══╝  ██║  ██║██║██║     ██╔══██║   ██║   ██╔══╝  
██║     ██║  ██║███████╗██████╔╝██║╚██████╗██║  ██║   ██║   ███████╗
╚═╝     ╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝ ╚═════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝
                                                                    
██╗      ██████╗  ██████╗ ██╗  ██╗██╗   ██╗██████╗ ███████╗
██║     ██╔═══██╗██╔═══██╗██║ ██╔╝██║   ██║██╔══██╗██╔════╝
██║     ██║   ██║██║   ██║█████╔╝ ██║   ██║██████╔╝███████╗
██║     ██║   ██║██║   ██║██╔═██╗ ██║   ██║██╔═══╝ ╚════██║
███████╗╚██████╔╝╚██████╔╝██║  ██╗╚██████╔╝██║     ███████║
╚══════╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚══════╝
*/



CREATE OR ALTER PROCEDURE 
    dbo.PredicateLookup 
(
    @Score int, 
    @CreationDate datetime
)
AS
BEGIN
SET XACT_ABORT, NOCOUNT ON;

SET STATISTICS XML ON;

    SELECT TOP (10000) 
        c.*
    FROM dbo.Comments AS c
    WHERE c.Score = @Score
    AND   c.CreationDate >= @CreationDate
    ORDER BY c.CreationDate DESC;

SET STATISTICS XML OFF;
END;
GO

/*
We have this index for some other query...

CREATE INDEX whatever 
ON dbo.Comments (Score, UserId, PostId) 
*/

/*This is fast!*/
EXEC dbo.PredicateLookup 
    @Score = 6, /*Sixer: Very selective predicate*/
    @CreationDate = '2013-12-31';

/*This is not so much*/
EXEC dbo.PredicateLookup 
    @Score = 0, /*El Zero: The opposite of a selective predicate*/
    @CreationDate = '2013-12-31';


/*

Lookups can often be much faster. 

You shouldn't focus on "fixing" all of them.

Predicate lookups are different. 

They're a sign you have incomplete indexes.

*/




/*We don't have to fix the entire lookup for this to be fast*/
CREATE INDEX 
    keys_only
ON dbo.Comments 
    (Score, CreationDate) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

/*This is fast!*/
EXEC dbo.PredicateLookup 
    @Score = 6, /*Sixer*/
    @CreationDate = '2013-12-31';

/*Now this is too!*/
EXEC dbo.PredicateLookup 
    @Score = 0, /*El Zero*/
    @CreationDate = '2013-12-31';


/*

Being able to at least do all of your 
filtering in one index is often good enough.

*/


/*Even when we go back in time a bit*/
EXEC dbo.PredicateLookup 
    @Score = 6,
    @CreationDate = '2011-12-31';

EXEC dbo.PredicateLookup 
    @Score = 0,
    @CreationDate = '2011-12-31';
GO 



/*Less effective when we remove the TOP*/

CREATE OR ALTER PROCEDURE 
    dbo.PredicateLookup 
(
    @Score int, 
    @CreationDate datetime
)
AS
BEGIN
SET XACT_ABORT, NOCOUNT ON;

SET STATISTICS XML ON;

    SELECT /*TOP (10000)*/ 
        c.*
    FROM dbo.Comments AS c
    WHERE c.Score = @Score
    AND   c.CreationDate >= @CreationDate
    ORDER BY c.CreationDate DESC;

SET STATISTICS XML OFF;
END;
GO

/*As long as one predicate is selective, we're still okay*/
EXEC dbo.PredicateLookup 
    @Score = 6,
    @CreationDate = '2011-12-31';

/*

But when neither predicate is selective, the lookup stinks
Just look at the saved plan for this (02b Predicates Slow Plan)

Run this at home if you're bored

EXEC dbo.PredicateLookup 
    @Score = 0,
    @CreationDate = '2011-12-31';

*/



/*

Takeaways:

Lookups are fine for reliably low row counts

Things can really go off the rails when estimates are wrong, 
or parameters cause SQL Server to get confused.

*/