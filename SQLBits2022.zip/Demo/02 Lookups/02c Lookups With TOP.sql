﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
DBCC FREEPROCCACHE;

DECLARE 
    @x varchar(180) = 0x4946204558495354530D0A280D0A53454C45435420312F300D0A46524F4D207379732E636F6C756D6E7320415320630D0A574845524520632E6F626A6563745F6964203D204F424A4543545F49442827506F73747327290D0A414E4420632E6E616D65203D202754686544696666270D0A290D0A424547494E0D0A414C544552205441424C452064626F2E506F7374730D0A2020202044524F5020434F4C554D4E20546865446966663B0D0A454E44;

EXECUTE (@x);

ALTER TABLE 
    dbo.Posts 
ADD 
    TheDiff AS DATEDIFF
               (
                   YEAR, 
                   CreationDate, 
                   LastActivityDate
               );

CREATE INDEX 
    noiceR
ON dbo.Posts
    (PostTypeId, TheDiff, OwnerUserId) 
INCLUDE 
    (Score) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO



/*
████████╗ ██████╗ ██████╗ 
╚══██╔══╝██╔═══██╗██╔══██╗
   ██║   ██║   ██║██████╔╝
   ██║   ██║   ██║██╔═══╝ 
   ██║   ╚██████╔╝██║     
   ╚═╝    ╚═════╝ ╚═╝     
                                                                    
██╗      ██████╗  ██████╗ ██╗  ██╗██╗   ██╗██████╗ ███████╗
██║     ██╔═══██╗██╔═══██╗██║ ██╔╝██║   ██║██╔══██╗██╔════╝
██║     ██║   ██║██║   ██║█████╔╝ ██║   ██║██████╔╝███████╗
██║     ██║   ██║██║   ██║██╔═██╗ ██║   ██║██╔═══╝ ╚════██║
███████╗╚██████╔╝╚██████╔╝██║  ██╗╚██████╔╝██║     ███████║
╚══════╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚══════╝
*/






/*Our good friend*/
CREATE OR ALTER PROCEDURE 
    dbo.TopLookup 
(
    @Gap int, @PostTypeId int
)
AS 
SET NOCOUNT, XACT_ABORT ON;
BEGIN
SET STATISTICS XML ON;

    SELECT TOP (500) 
        u.DisplayName, 
        p.*
    FROM dbo.Posts AS p
    JOIN dbo.Users AS u
        ON u.Id = p.OwnerUserId
    /*This is only okay because of the computed column I created and indexed*/
    WHERE DATEDIFF(YEAR, p.CreationDate, p.LastActivityDate) > @Gap
    /*Normally I'd smack someone for writing a where clause like this*/
    AND   p.PostTypeId = @PostTypeId
    ORDER BY p.Score DESC;

SET STATISTICS XML OFF;
END;
GO 


/*Superstition*/
EXEC sys.sp_recompile 
    @objname = N'dbo.TopLookup';

/*Small Gap: Just fine!*/
EXEC dbo.TopLookup 
    @Gap = 9, 
    @PostTypeId = 1;

/*Big Gap: Not so much*/
EXEC dbo.TopLookup 
    @Gap = 0, 
    @PostTypeId = 1;


/*Superstition*/
EXEC sys.sp_recompile 
    @objname = N'dbo.TopLookup';

/*Big Gap: The plan changed and got weird*/
EXEC dbo.TopLookup 
    @Gap = 0, 
    @PostTypeId = 2;

/*Small Gap: This is way slower, even with the big plan*/
EXEC dbo.TopLookup 
    @Gap = 9, 
    @PostTypeId = 2;
GO 

/*

Things to note: 
* Plan changes
 * Index usage
 * Scans 
 * Parallelism

*/


























/*

We're going to do a self join with Posts
* Alias p: Join, Where Clause, Order By
* Alias p2: Select list

Separating relational from informational duties!

*/
CREATE OR ALTER PROCEDURE 
    dbo.TopLookup 
(
    @Gap int, 
    @PostTypeId int
)
AS 
SET NOCOUNT, XACT_ABORT ON;
BEGIN
SET STATISTICS XML ON;

    SELECT TOP (500) 
        u.DisplayName,
        p2.* /*From p2*/
    FROM dbo.Posts AS p1
    JOIN dbo.Posts AS p2 /*This is new*/
        ON p1.Id = p2.Id
    JOIN dbo.Users AS u
        ON u.Id = p1.OwnerUserId /*From p1, join, where, order by*/
    WHERE DATEDIFF(YEAR, p1.CreationDate, p1.LastActivityDate) > @Gap
    AND   p1.PostTypeId = @PostTypeId
    ORDER BY p1.Score DESC;

SET STATISTICS XML OFF;
END;
GO 


/*Superstition*/
EXEC sys.sp_recompile 
    @objname = N'dbo.TopLookup';

/*These are both fast*/
EXEC dbo.TopLookup 
    @Gap = 9, 
    @PostTypeId = 2;

EXEC dbo.TopLookup 
    @Gap = 0, 
    @PostTypeId = 2;

/*Superstition*/
EXEC sys.sp_recompile 
    @objname = N'dbo.TopLookup';

/*These are both fast, too*/
EXEC dbo.TopLookup 
    @Gap = 0, 
    @PostTypeId = 2;

EXEC dbo.TopLookup 
    @Gap = 9, 
    @PostTypeId = 2;

/*Only real difference: Parallelism for the big plan.*/
GO 




 



















/*

Turn on query plans for this.

Looking at them back to back, where is the Sort placed?

*/
CREATE OR ALTER PROCEDURE 
    dbo.TopLookup 
(
    @Gap int, 
    @PostTypeId int
)
AS 
SET NOCOUNT, XACT_ABORT ON;
BEGIN

    SELECT TOP (500) 
        u.DisplayName, 
        p.*
    FROM dbo.Posts AS p
    JOIN dbo.Users AS u
        ON u.Id = p.OwnerUserId
    WHERE DATEDIFF(YEAR, p.CreationDate, p.LastActivityDate) > @Gap
    AND   p.PostTypeId = @PostTypeId
    ORDER BY p.Score DESC;

    SELECT TOP (500) 
        u.DisplayName,
        p2.*
    FROM dbo.Posts AS p
    JOIN dbo.Posts AS p2
        ON p.Id = p2.Id
    JOIN dbo.Users AS u
        ON u.Id = p.OwnerUserId
    WHERE DATEDIFF(YEAR, p.CreationDate, p.LastActivityDate) > @Gap
    AND   p.PostTypeId = @PostTypeId
    ORDER BY p.Score DESC;

END;
GO 



EXEC sys.sp_recompile 
    @objname = N'dbo.TopLookup';

EXEC dbo.TopLookup 
    @Gap = 9, 
    @PostTypeId = 2;

EXEC dbo.TopLookup 
    @Gap = 0, 
    @PostTypeId = 2;


/*
Please get rid of me so I don't mess up other demos.
*/
EXEC dbo.DropIndexes;

ALTER TABLE 
    dbo.Posts
DROP COLUMN 
    TheDiff;
