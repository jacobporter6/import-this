﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
DBCC FREEPROCCACHE;


/*
██╗      ██████╗  ██████╗ ██╗  ██╗██╗   ██╗██████╗ ███████╗
██║     ██╔═══██╗██╔═══██╗██║ ██╔╝██║   ██║██╔══██╗██╔════╝
██║     ██║   ██║██║   ██║█████╔╝ ██║   ██║██████╔╝███████╗
██║     ██║   ██║██║   ██║██╔═██╗ ██║   ██║██╔═══╝ ╚════██║
███████╗╚██████╔╝╚██████╔╝██║  ██╗╚██████╔╝██║     ███████║
╚══════╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚══════╝
*/


/*
We have this index
*/
CREATE INDEX 
    reppo 
ON dbo.Users 
    (Reputation) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);


/*
We have this query
And we should turn on query plans

Where do all the columns in the * come from?
*/

--For just select list columns
SELECT 
    u.*
FROM dbo.Users AS u
WHERE u.Reputation = 942;

--For the where clause, too
SELECT 
    u.*
FROM dbo.Users AS u
WHERE u.Reputation = 942
AND   u.DisplayName = N'Eggs McLaren';



/*

The optimizer costs lookups much higher than
alternative access methods, because it assumes
you're on crappy old rotational storage where
random I/O means physical movement.

*/