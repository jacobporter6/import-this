﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
DBCC TRACEON(8649);
DBCC FREEPROCCACHE;
GO 


/*
Create these ahead of time, if you can
*/

CREATE INDEX 
    users
ON dbo.Users 
    (CreationDate, Reputation, Id) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO

CREATE INDEX 
    posts
ON dbo.Posts 
    (OwnerUserId, Id)
INCLUDE 
    (PostTypeId)
WHERE 
    (PostTypeId = 1)
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO



/*
██████╗ ███████╗██╗      █████╗ ████████╗██╗ ██████╗ ███╗   ██╗ █████╗ ██╗     
██╔══██╗██╔════╝██║     ██╔══██╗╚══██╔══╝██║██╔═══██╗████╗  ██║██╔══██╗██║     
██████╔╝█████╗  ██║     ███████║   ██║   ██║██║   ██║██╔██╗ ██║███████║██║     
██╔══██╗██╔══╝  ██║     ██╔══██║   ██║   ██║██║   ██║██║╚██╗██║██╔══██║██║     
██║  ██║███████╗███████╗██║  ██║   ██║   ██║╚██████╔╝██║ ╚████║██║  ██║███████╗
╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝
                                                                               
 ██████╗████████╗███████╗███████╗
██╔════╝╚══██╔══╝██╔════╝██╔════╝
██║        ██║   █████╗  ███████╗
██║        ██║   ██╔══╝  ╚════██║
╚██████╗   ██║   ███████╗███████║
 ╚═════╝   ╚═╝   ╚══════╝╚══════╝                                 
*/


/*

I have this demo because people always ask
 * Should I use a temp table or a CTE?

We need to understand they’re totally different
 * Temp tables are physical objects

CTEs are just queries, not ever materialized (current product versions; maybe future?)
 * So let’s see where CTEs work, and then don’t work
 * Using TOP in a CTE or derived table does provide logical optimization fences
 * https://dba.stackexchange.com/questions/221555/what-rules-determine-when-sql-server-use-a-cte-as-an-optimization-fence

This demo is to show you that CTEs can seem magical,
but the optimizer can rewrite them and mess things up.

This demo is not to show you that CTEs are good. It's sort of the opposite.

If you want to materialize a result, use a #temp table.

*/



/*

These are our indexes. The optimizer would be smart to use them.

We're smart. We make smart indexes.

    CREATE INDEX 
        users
    ON dbo.Users 
        (CreationDate, Reputation, Id);
    GO
    
    CREATE INDEX 
        posts
    ON dbo.Posts 
        (OwnerUserId, Id)
    INCLUDE 
        (PostTypeId)
    WHERE 
        (PostTypeId = 1);

The filter here isn't anything magickal, it just creates faster.
*/


CREATE OR ALTER PROCEDURE 
    dbo.RelationalCTE 
(
    @CreationDate datetime
)
AS
BEGIN
SET XACT_ABORT, NOCOUNT ON;

SET STATISTICS XML ON;

    SELECT TOP (1000) 
        u.*, --Everything, again.
        PostId = p.Id
    FROM dbo.Users AS u
    JOIN dbo.Posts AS p
        ON p.OwnerUserId = u.Id
    WHERE  u.CreationDate > @CreationDate 
    AND    u.Reputation > 100
    AND    p.PostTypeId = 1
    ORDER BY u.Id;

SET STATISTICS XML OFF;

END;
GO


EXEC dbo.RelationalCTE 
    @CreationDate = '20131210';
GO 


/*

Was the optimizer smart? 

*/





/*

Overpowered!

*/
CREATE OR ALTER PROCEDURE 
    dbo.RelationalCTE 
(
    @CreationDate datetime
)
AS
BEGIN
SET XACT_ABORT, NOCOUNT ON;

SET STATISTICS XML ON;

    SELECT TOP (1000) 
        u.*, 
        PostId = p.Id
    FROM dbo.Users AS u WITH (INDEX = users) /* TAKE A HINT! */
    JOIN dbo.Posts AS p
        ON p.OwnerUserId = u.Id
    WHERE  u.CreationDate > @CreationDate 
    AND    u.Reputation > 100
    AND    p.PostTypeId = 1
    ORDER BY u.Id;

SET STATISTICS XML OFF;

END;
GO

/*

This turns out way better with the hint, yes?

But why? Why didn't our index get used?

Remember when I said that the optimizer costs these things poorly?

*/

EXEC dbo.RelationalCTE 
    @CreationDate = '20131210';
GO 



/*Let's look at those back to back*/

CREATE OR ALTER PROCEDURE 
    dbo.RelationalCTE 
(
    @CreationDate datetime
)
AS
BEGIN
SET XACT_ABORT, NOCOUNT ON;

SET STATISTICS XML ON;

    SELECT TOP (1000) 
        u.*, 
        PostId = p.Id
    FROM dbo.Users AS u /* TAKE NO HINT! */
    JOIN dbo.Posts AS p
        ON p.OwnerUserId = u.Id
    WHERE  u.CreationDate > @CreationDate 
    AND    u.Reputation > 100
    AND    p.PostTypeId = 1
    ORDER BY u.Id;

    SELECT TOP (1000) 
        u.*, 
        PostId = p.Id
    FROM dbo.Users AS u WITH (INDEX = users) /* TAKE A HINT! */
    JOIN dbo.Posts AS p
        ON p.OwnerUserId = u.Id
    WHERE  u.CreationDate > @CreationDate 
    AND    u.Reputation > 100
    AND    p.PostTypeId = 1
    ORDER BY u.Id;

SET STATISTICS XML OFF;

END;
GO


/*Turn on query plans here to compare back to back*/
EXEC dbo.RelationalCTE 
    @CreationDate = '20131210';
GO 

/*

Costing! What's "expensive" in the second plan?

*/






/*

Informational vs. Relational Columns

Remember that thing?
 * Relational: Where, Join, Order/Group By
 * Informational: SELECT (poor, lonely select)

*/

CREATE OR ALTER PROCEDURE 
    dbo.RelationalCTE 
(
    @CreationDate datetime
)
AS
BEGIN
SET XACT_ABORT, NOCOUNT ON;

SET STATISTICS XML ON;

    WITH 
        precheck AS 
    (
        /*Technically you need a TOP (int or bigint max) to fence things off here*/
        SELECT --TOP (9223372036854775807) 
            u.Id, /*Narrow SELECT*/
            PostId = p.Id 
        FROM dbo.Users AS u
        JOIN dbo.Posts AS p
            ON p.OwnerUserId = u.Id /*Same join*/
        WHERE  u.CreationDate > @CreationDate /*Same predicates*/
        AND    u.Reputation > 100 /*...*/
        AND    p.PostTypeId = 1 /*...*/
    )
    SELECT
        u.*, 
        p.PostId
    FROM precheck p
    LEFT JOIN dbo.Users AS u
        ON p.Id = u.Id /*Join Users back to the CTE on just the Ids we need*/
    ORDER BY u.Id;

SET STATISTICS XML OFF;

END;
GO

/*


 
*/

/*Still okay*/
EXEC dbo.RelationalCTE 
    @CreationDate = '20131210';

EXEC sys.sp_recompile 
    @objname = 'dbo.RelationalCTE';

/*What happens now?*/
EXEC dbo.RelationalCTE 
    @CreationDate = '20101210';

/*Run me so I don't mess up other demos*/
DBCC TRACEOFF(8649);
GO 

/*
Takeaways:
 * CTEs are kind of dumb, at least without a TOP
 * Don't make queries more readable: Formatting does!
 * To truly separate and materialize things, you need a #temp table

The only way to guarantee _separation_ 
from a CTE or derived table is to use TOP.

Note that this DOES NOT _materialize_ a CTE 
or derived table. At all. Ever. Never ever.

Run this on your own:
    
    WITH
        t AS
    (
        SELECT TOP (1)
            u.*
        FROM dbo.Users AS u
    )
    SELECT
        t.*
    FROM t
    JOIN t AS t2
        ON t.Id = t2.Id
    JOIN t AS t3
        ON t.Id = t3.Id;

What happens in the query plan? 
How many times does Users get scanned?
How many TOP operators are there?

Notes:
 * I use a LEFT JOIN in the CTE query because the 
   optimizer had a harder time reordering those
 * Also because if I don't, the optimizer chooses
   a parallel merge join that has three exchange
   spills and runs for several minutes.

*/

