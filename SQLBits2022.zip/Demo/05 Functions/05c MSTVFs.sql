﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
GO 


/*
███╗   ███╗███████╗████████╗██╗   ██╗███████╗███████╗
████╗ ████║██╔════╝╚══██╔══╝██║   ██║██╔════╝██╔════╝
██╔████╔██║███████╗   ██║   ██║   ██║█████╗  ███████╗
██║╚██╔╝██║╚════██║   ██║   ╚██╗ ██╔╝██╔══╝  ╚════██║
██║ ╚═╝ ██║███████║   ██║    ╚████╔╝ ██║     ███████║
╚═╝     ╚═╝╚══════╝   ╚═╝     ╚═══╝  ╚═╝     ╚══════╝
*/



/*
 __        __                  ___         __        
|__)  /\  |__)  /\  |    |    |__  |    | /__`  |\/| 
|    /~~\ |  \ /~~\ |___ |___ |___ |___ | .__/  |  |                                                   
*/

CREATE INDEX 
    chuck_d 
ON dbo.Badges
    (UserId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

/*A regular table variable!*/
DECLARE 
    @Out table 
(
    UserId int, 
    BadgeCount bigint
);

/*An interesting parallelism restriction, more on this later though...*/
INSERT INTO 
    @Out 
(
    UserId, 
    BadgeCount
)
SELECT 
    b.UserId, 
    BadgeCount = 
        COUNT_BIG(*)
FROM dbo.Badges AS b
GROUP BY b.UserId
HAVING COUNT_BIG(*) > 0;

/*Parallelism on the read from table variable*/
SELECT 
    u.Id,
    o.*
FROM dbo.Users AS u
JOIN @Out AS o
    ON o.UserId = u.Id
WHERE u.LastAccessDate >= '20180901'
OPTION (RECOMPILE);
GO


/*Creating a MSTVF, retrurns a @table variable*/
CREATE OR ALTER FUNCTION 
    dbo.BadgerJoin
(
    @h bigint
)
RETURNS 
    @Out table
(
    UserId int, 
    BadgeCount bigint
)
AS
BEGIN
    INSERT INTO 
        @Out 
    (
        UserId, 
        BadgeCount
    )
    SELECT 
        b.UserId, 
        BadgeCount = 
            COUNT_BIG(*)
    FROM dbo.Badges AS b
    GROUP BY b.UserId
    HAVING COUNT_BIG(*) > @h;
    RETURN;
END;
GO

/*Does parallelism happen?*/
SELECT 
    u.Id,
    o.*
FROM dbo.Users AS u
JOIN dbo.BadgerJoin(0) AS o
    ON o.UserId = u.Id
WHERE u.LastAccessDate >= '20180901'
OPTION(RECOMPILE);

SELECT 
    u.Id,
    o.*
FROM dbo.Users AS u
JOIN dbo.BadgerJoin(0) AS o
    ON o.UserId = u.Id
WHERE u.LastAccessDate >= '20180901'
OPTION(QUERYTRACEON 8649);


/*

 You can:
  * Read from a table variable in parallel
  * Unless it's returned by a MSTVF
   * Other table variables reads in one can happen with parallelism

Lots of MSTVF fixes are similar to SVF rewrites.
 * Rewrite as iTVFs
 * Separate from critical code
 * Dump into #temp table
 * I end up doing this for many string splitter functions

*/