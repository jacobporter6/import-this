﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;
GO 

CREATE INDEX 
    stinkin_badges 
ON dbo.Badges
    (UserId, Name) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    vote_fraud 
ON dbo.Votes
    (UserId) 
INCLUDE
   (BountyAmount) 
WHERE 
    (UserId IS NOT NULL)
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 

/*
███████╗ ██████╗ █████╗ ██╗      █████╗ ██████╗                           
██╔════╝██╔════╝██╔══██╗██║     ██╔══██╗██╔══██╗                          
███████╗██║     ███████║██║     ███████║██████╔╝                          
╚════██║██║     ██╔══██║██║     ██╔══██║██╔══██╗                          
███████║╚██████╗██║  ██║███████╗██║  ██║██║  ██║                          
╚══════╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝                          
                                                                          
███████╗██╗   ██╗███╗   ██╗ ██████╗████████╗██╗ ██████╗ ███╗   ██╗███████╗
██╔════╝██║   ██║████╗  ██║██╔════╝╚══██╔══╝██║██╔═══██╗████╗  ██║██╔════╝
█████╗  ██║   ██║██╔██╗ ██║██║        ██║   ██║██║   ██║██╔██╗ ██║███████╗
██╔══╝  ██║   ██║██║╚██╗██║██║        ██║   ██║██║   ██║██║╚██╗██║╚════██║
██║     ╚██████╔╝██║ ╚████║╚██████╗   ██║   ██║╚██████╔╝██║ ╚████║███████║
╚═╝      ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝
*/


/*

The problems with T-SQL Scalar UDFs:
 * Force the query that calls them to run single threaded (no parallelism)
 * Run once per row, not once per query
  * Function in select list? Once per returned row.
  * Function in join or where clause? Once per row in table.

SQL Server 2019 function inlining is cool, but lots of limitations:
 * https://docs.microsoft.com/en-us/sql/relational-databases/user-defined-functions/scalar-udf-inlining?view=sql-server-ver15#inlineable-scalar-udfs-requirements
 * Currently ~30 documented restrictions
  * GETDATE()
  * CTEs
  * String building
  * GROUP BY
  * ORDER BY
  * Lots more!

*/




/*
 __   ___       __    ___  ___  __  
|__) |__  |  | |__) |  |  |__  /__` 
|  \ |___ |/\| |  \ |  |  |___ .__/

*/


/*
Here's our function. It adds scores up across two tables.
*/
CREATE OR ALTER FUNCTION 
    dbo.TotalScore
(
    @UserId int
)  
RETURNS bigint  
WITH RETURNS NULL ON NULL INPUT, /*This is great if your columns have NULLs*/
    SCHEMABINDING /*This can help performance in limited situations*/              
AS   
BEGIN  

    DECLARE 
        @TotalScore bigint; 
        
    SELECT  
        @TotalScore =   
            (  
                SELECT 
                    ISNULL(SUM(p.Score), 0)  
                FROM dbo.Posts AS p  
                WHERE p.OwnerUserId = @UserId  
            ) +  
            (  
                SELECT 
                    ISNULL(SUM(c.Score), 0)  
                FROM dbo.Comments AS c  
                WHERE c.UserId = @UserId  
            );   
        
    RETURN @TotalScore; 
    
END;
GO




/*
Without the function this is pretty fast
*/
SELECT 
    u.Id, 
    u.DisplayName, 
    u.Reputation,
    LastBadge = 
        ( 
            SELECT 
                COUNT(DISTINCT b.Name)
            FROM dbo.Badges AS b
            WHERE b.UserId = u.Id 
        ),
    TotalBounties = 
        ( 
            SELECT 
                SUM(ISNULL(v.BountyAmount, 0))
            FROM dbo.Votes AS v
            WHERE v.UserId = u.Id 
        )
FROM dbo.Users AS u
WHERE u.Reputation >= 20000
ORDER BY u.Reputation DESC;



/*
With the function this is awful

Show the saved plan

Contrast with estimated plan!
*/
SELECT 
    u.Id, 
    u.DisplayName, 
    u.Reputation,
    LastBadge = 
        ( 
            SELECT 
                COUNT(DISTINCT b.Name)
            FROM dbo.Badges AS b
            WHERE b.UserId = u.Id 
        ),
    TotalBounties = 
        ( 
            SELECT 
                SUM(ISNULL(v.BountyAmount, 0))
            FROM dbo.Votes AS v
            WHERE v.UserId = u.Id 
        ),
    TotalScore = 
        dbo.TotalScore(u.Id) /*Lend me some sugar, I am your function*/
FROM dbo.Users AS u
WHERE u.Reputation >= 20000
ORDER BY u.Reputation DESC;
GO 

/*Create these while you go look at the saved plan...*/
CREATE INDEX 
    p 
ON dbo.Posts
    (OwnerUserId) 
INCLUDE
    (Score) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    c 
ON dbo.Comments
    (UserId) 
INCLUDE
    (Score) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 


/*
Rewrite as an inline function...
*/
CREATE OR ALTER FUNCTION 
    dbo.TotalScore_Inline
(
    @UserId int
)  
RETURNS table  /*Returns table*/
WITH SCHEMABINDING                
AS   
RETURN /*No variable assignment, only returns a select*/
    SELECT 
        TotalScore =   
            (  
                SELECT 
                    ISNULL(SUM(p.Score), 0)  
                FROM dbo.Posts AS p  
                WHERE p.OwnerUserId = @UserId  
            ) +  
            (  
                SELECT 
                    ISNULL(SUM(c.Score), 0)  
                FROM dbo.Comments AS c  
                WHERE c.UserId = @UserId  
            );      
GO 


/*
Scalar
*/
DBCC FREEPROCCACHE;

SELECT 
    u.Id, 
    u.DisplayName, 
    u.Reputation,
    LastBadge = 
        ( 
            SELECT 
                COUNT(DISTINCT b.Name)
            FROM dbo.Badges AS b
            WHERE b.UserId = u.Id 
        ),
    TotalBounties = 
        ( 
            SELECT 
                SUM(ISNULL(v.BountyAmount, 0))
            FROM dbo.Votes AS v
            WHERE v.UserId = u.Id 
        ),
    TotalScore = 
        dbo.TotalScore(u.Id) /*Lend me some sugar, I am your function*/
FROM dbo.Users AS u
WHERE u.Reputation >= 20000
ORDER BY u.Reputation DESC;
GO 

/*
Inline
*/
SELECT 
    u.Id, 
    u.DisplayName, 
    u.Reputation,
    LastBadge = 
        ( 
            SELECT 
                COUNT(DISTINCT b.Name)
            FROM dbo.Badges AS b
            WHERE b.UserId = u.Id 
        ),
    TotalBounties = 
        ( 
            SELECT 
                SUM(ISNULL(v.BountyAmount, 0))
            FROM dbo.Votes AS v
            WHERE v.UserId = u.Id 
        ),
    TotalScore = 
        (
            SELECT 
                t.* 
            FROM dbo.TotalScore_Inline(u.Id) AS t
        ) /*Lend me some sugar, I am your function*/
FROM dbo.Users AS u
WHERE u.Reputation >= 20000
ORDER BY u.Reputation DESC;
GO 


SELECT 
    function_name = 
        OBJECT_NAME(defs.object_id),
    defs.execution_count,
    total_worker_time_ms = 
        defs.total_worker_time / 1000.,
    total_elapsed_time_ms = 
        defs.total_elapsed_time / 1000.
FROM sys.dm_exec_function_stats AS defs;









/*
   __   __            ___    __       
| /__` /  \ |     /\   |  | /  \ |\ | 
| .__/ \__/ |___ /~~\  |  | \__/ | \|

*/



EXEC dbo.DropIndexes;
DBCC FREEPROCCACHE;


/*Show them the function while this creates, dummy*/
CREATE INDEX 
    north 
ON dbo.Votes
    (PostId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    south 
ON dbo.Badges
    (UserId, Date) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    east 
ON dbo.Posts
    (PostTypeId, Score, OwnerUserId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    west 
ON dbo.Comments
    (UserId, PostId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 


/*

dbo.InitCap appears courtesy of: 
https://www.sqlservercentral.com/forums/topic/first-and-first-character-after-space-should-be-capital#post-1227491

Jeff Moden is a very smart guy.

*/

/*

It's nice when you can rewrite functions, but sometimes it's not possible.

Either it's too complex, or the logic doesn't fit for an inline table valued function.

What other options do we have?

*/

CREATE OR ALTER FUNCTION dbo.InitialCap (@String varchar(8000))
RETURNS varchar(8000)
AS
    BEGIN
        DECLARE @Position int;
        
        SELECT  @String = STUFF(LOWER(@String), 1, 1, UPPER(LEFT(@String, 1))) COLLATE Latin1_General_BIN,
                @Position = PATINDEX('%[^A-Za-z''][a-z]%', @String COLLATE Latin1_General_BIN);
                
        WHILE   @Position > 0
        SELECT  @String = STUFF(@String, @Position, 2, UPPER(SUBSTRING(@String, @Position, 2))) COLLATE Latin1_General_BIN,
                @Position = PATINDEX('%[^A-Za-z''][a-z]%', @String COLLATE Latin1_General_BIN);
        
        RETURN @String;
    END;
GO 


/*Icky yucky!*/
SELECT   
    u.Id,
    u.Reputation,
    FormattedDisplayName =
        dbo.InitialCap(u.DisplayName), /*Our function*/
    TopPostScore = 
        ( 
            SELECT 
                MAX(p.Score) 
            FROM dbo.Posts AS p 
            WHERE p.OwnerUserId = u.Id 
            AND p.PostTypeId IN (1, 2) 
        ),
    TopCommentScore = 
        ( 
            SELECT 
                MAX(c.Score) 
            FROM dbo.Comments AS c 
            WHERE c.UserId = u.Id 
        ),
    LatestBadge = 
        ( 
            SELECT TOP (1) 
                b.Name
            FROM dbo.Badges AS b
            WHERE b.UserId = u.Id
            ORDER BY b.Date DESC 
        ),
    PostId = 
        p.Id,
    p.Title,
    VoteCount = 
        ( 
            SELECT 
                COUNT_BIG(*) 
            FROM dbo.Votes AS v 
            WHERE v.PostId = p.Id 
        )
FROM dbo.Users AS u
JOIN dbo.Posts AS p
    ON p.OwnerUserId = u.Id
WHERE u.Reputation >= 1000
AND   p.PostTypeId = 1
AND   p.Score >= 1000 
ORDER BY u.Reputation DESC;
    
 


/*
What's the function doing now?
*/
SELECT 
    function_name = 
        OBJECT_NAME(defs.object_id),
    defs.execution_count,
    total_worker_time_ms = 
        defs.total_worker_time / 1000.,
    total_elapsed_time_ms = 
        defs.total_elapsed_time / 1000.
FROM sys.dm_exec_function_stats AS defs;
















/*Well hey now*/

/*
How long does it run without the function?
*/
SELECT   
    u.Id,
    u.Reputation,
    u.DisplayName, /*No function, just the column we need for it*/
    TopPostScore = 
        ( 
            SELECT 
                MAX(p.Score) 
            FROM dbo.Posts AS p 
            WHERE p.OwnerUserId = u.Id 
            AND p.PostTypeId IN (1, 2) 
        ),
    TopCommentScore = 
        ( 
            SELECT 
                MAX(c.Score) 
            FROM dbo.Comments AS c 
            WHERE c.UserId = u.Id 
        ),
    LatestBadge = 
        ( 
            SELECT TOP (1) 
                b.Name
            FROM dbo.Badges AS b
            WHERE b.UserId = u.Id
            ORDER BY b.Date DESC 
        ),
    PostId = 
        p.Id,
    p.Title,
    VoteCount = 
        ( 
            SELECT 
                COUNT_BIG(*) 
            FROM dbo.Votes AS v 
            WHERE v.PostId = p.Id 
        )
FROM dbo.Users AS u
JOIN dbo.Posts AS p
    ON p.OwnerUserId = u.Id
WHERE u.Reputation >= 1000
AND   p.PostTypeId = 1
AND   p.Score >= 1000 
ORDER BY u.Reputation DESC;
    
    
    
    

 
 


















    
/*Easy win?*/
DROP TABLE IF EXISTS #t;

SELECT   
    u.Id,
    u.Reputation,
    u.DisplayName, /*No function*/
    TopPostScore = 
        ( 
            SELECT 
                MAX(p.Score) 
            FROM dbo.Posts AS p 
            WHERE p.OwnerUserId = u.Id 
            AND p.PostTypeId IN (1, 2) 
        ),
    TopCommentScore = 
        ( 
            SELECT 
                MAX(c.Score) 
            FROM dbo.Comments AS c 
            WHERE c.UserId = u.Id 
        ),
    LatestBadge = 
        ( 
            SELECT TOP (1) 
                b.Name
            FROM dbo.Badges AS b
            WHERE b.UserId = u.Id
            ORDER BY b.Date DESC 
        ),
    PostId = 
        p.Id,
    p.Title,
    VoteCount = 
        ( 
            SELECT 
                COUNT_BIG(*) 
            FROM dbo.Votes AS v 
            WHERE v.PostId = p.Id 
        )
INTO #t
FROM dbo.Users AS u
JOIN dbo.Posts AS p
    ON p.OwnerUserId = u.Id
WHERE u.Reputation >= 1000
AND   p.PostTypeId = 1
AND   p.Score >= 1000 
ORDER BY u.Reputation DESC;
/*What's still slow here? Stay tuned!*/


SELECT 
    t.Id, 
    t.Reputation, 
    FormattedDisplayName = 
        dbo.InitialCap(t.DisplayName), 
    t.TopPostScore, 
    t.TopCommentScore, 
    t.LatestBadge,
    t.PostId, 
    t.Title, 
    t.VoteCount
FROM #t AS t
ORDER BY t.Reputation DESC;






















/*
      __   __                 
 /\  |__) |__) |    \ /       
/~~\ |    |    |___  |        
                              
                     ___  __  
\  /  /\  |    |  | |__  /__` 
 \/  /~~\ |___ \__/ |___ .__/ 

*/
EXEC dbo.DropIndexes; 

CREATE INDEX 
    p 
ON dbo.Posts
    (OwnerUserId) 
INCLUDE
    (Score) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    c 
ON dbo.Comments
    (UserId)   
INCLUDE
    (Score) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

DBCC FREEPROCCACHE;
GO 

/*Our old friend TotalScore*/
/*

In this case, the function is invoked twice separately
for each condition in the AND clause

*/
SELECT 
    u.DisplayName, 
    u.Reputation
FROM dbo.Users AS u
WHERE u.Reputation >= 100000
AND   dbo.TotalScore(u.Id) >= 10000
AND   dbo.TotalScore(u.Id) < 20000
ORDER BY u.Id;
GO 

/*HRRRRRRRRM.*/
SELECT 
    function_name = 
        OBJECT_NAME(defs.object_id),
    defs.execution_count,
    total_worker_time_ms = 
        defs.total_worker_time / 1000.,
    total_elapsed_time_ms = 
        defs.total_elapsed_time / 1000.
FROM sys.dm_exec_function_stats AS defs;



DBCC FREEPROCCACHE;
GO 
/*Doth BETWIXT helpeth?*/
SELECT 
    u.DisplayName, 
    u.Reputation
FROM dbo.Users AS u
WHERE u.Reputation >= 100000
AND   dbo.TotalScore(u.Id) BETWEEN 10000 AND 20000
ORDER BY u.Id;
GO 

SELECT 
    function_name = 
        OBJECT_NAME(defs.object_id),
    defs.execution_count,
    total_worker_time_ms = 
        defs.total_worker_time / 1000.,
    total_elapsed_time_ms = 
        defs.total_elapsed_time / 1000.
FROM sys.dm_exec_function_stats AS defs;



DBCC FREEPROCCACHE;
GO 
/*Valyoo*/
SELECT 
    u.DisplayName,
    u.Reputation
FROM dbo.Users AS u
CROSS APPLY
(
    VALUES 
        (
            dbo.TotalScore(u.Id)
        )
) AS t (Score)
WHERE u.Reputation >= 100000
AND   t.Score >= 10000
AND   t.Score < 20000
ORDER BY u.Id;
GO 

SELECT 
    function_name = 
        OBJECT_NAME(defs.object_id),
    defs.execution_count,
    total_worker_time_ms = 
        defs.total_worker_time / 1000.,
    total_elapsed_time_ms = 
        defs.total_elapsed_time / 1000.
FROM sys.dm_exec_function_stats AS defs;
GO 




/*

The problems with Scalar UDFs:
* Force calling query to run single threaded (no parallelism)
* Run once per row processed, not once per query
* Often glue queries up badly
* Just as bad in computed columns or check constraints -- don't do it!

Lots of limitations and restrictions in SQL Server 2019, with UDF inlining:
* https://docs.microsoft.com/en-us/sql/relational-databases/user-defined-functions/scalar-udf-inlining?view=sql-server-ver15#inlineable-scalar-udfs-requirements

*/