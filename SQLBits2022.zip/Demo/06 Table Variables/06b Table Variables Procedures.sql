﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 150;

CREATE INDEX 
    veto 
ON dbo.Votes
     (PostId) 
INCLUDE
    (VoteTypeId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    pet_sounds 
ON dbo.Posts
    (CreationDate) 
INCLUDE
    (OwnerUserId, Score, PostTypeId) 
WHERE 
    (PostTypeId = 1)
WITH(MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    agggggg 
ON dbo.Comments
    (PostId, UserId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 

/*
████████╗ █████╗ ██████╗ ██╗     ███████╗                  
╚══██╔══╝██╔══██╗██╔══██╗██║     ██╔════╝                  
   ██║   ███████║██████╔╝██║     █████╗                    
   ██║   ██╔══██║██╔══██╗██║     ██╔══╝                    
   ██║   ██║  ██║██████╔╝███████╗███████╗                  
   ╚═╝   ╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝                  
                                                           
███████╗███╗   ██╗██╗███████╗███████╗██╗███╗   ██╗ ██████╗ 
██╔════╝████╗  ██║██║██╔════╝██╔════╝██║████╗  ██║██╔════╝ 
███████╗██╔██╗ ██║██║█████╗  █████╗  ██║██╔██╗ ██║██║  ███╗
╚════██║██║╚██╗██║██║██╔══╝  ██╔══╝  ██║██║╚██╗██║██║   ██║
███████║██║ ╚████║██║██║     ██║     ██║██║ ╚████║╚██████╔╝
╚══════╝╚═╝  ╚═══╝╚═╝╚═╝     ╚═╝     ╚═╝╚═╝  ╚═══╝ ╚═════╝ 
*/

CREATE OR ALTER PROCEDURE 
    dbo.PostInfo
(
    @StartDate datetime, 
    @EndDate datetime
)
AS
SET NOCOUNT, XACT_ABORT ON;
BEGIN

DECLARE 
    @Votes table
( 
    PostId int NOT NULL, 
    OwnerUserId int NOT NULL, 
    Score int NOT NULL, 
    UpVotes int NOT NULL, 
    Downvotes int NOT NULL,
    INDEX c CLUSTERED 
        (PostId, OwnerUserId) 
);

INSERT 
    @Votes
(
    PostId,
    OwnerUserId,
    Score,
    UpVotes,
    Downvotes
)
EXEC sys.sp_executesql N'
SELECT 
    p.Id, 
    p.OwnerUserId,
    p.Score,
    UpVotes = SUM(CASE WHEN v.VoteTypeId = 2 THEN 1 ELSE 0 END), 
    Downvotes = SUM(CASE WHEN v.VoteTypeId = 3 THEN 1 ELSE 0 END) 
FROM dbo.Votes AS v
JOIN dbo.Posts AS p
ON p.Id = v.PostId
WHERE p.CreationDate >= @StartDate
AND   p.CreationDate <  @EndDate
AND   p.PostTypeId = 1
GROUP BY 
    p.Id,
    p.OwnerUserId,
    p.Score
OPTION(RECOMPILE);',
N'@StartDate datetime, 
  @EndDate datetime', 
  @StartDate, 
  @EndDate;
/*

Doing the insert as part of a dynamic SQL block,
or with a stored procedure bypasses the restriction
on underlying queries using parallelism, but the
insert will still happen on a single thread.

*/

SELECT TOP (1000)
    u.Id, 
    u.DisplayName, 
    u.Reputation,
    v.PostId, 
    v.Score, 
    v.UpVotes, 
    v.Downvotes,
    p.Title, 
    p.Tags,
    c.Score, 
    c.Text
FROM @Votes AS v
LEFT JOIN dbo.Posts AS p
    ON p.Id = v.PostId
LEFT JOIN dbo.Comments AS c
    ON  v.PostId = c.PostId
    AND v.OwnerUserId = c.UserId
LEFT JOIN dbo.Users AS u
    ON u.Id = v.OwnerUserId
ORDER BY c.Score DESC;

END;
GO 

/*Narrow range, good estimate?*/
EXEC dbo.PostInfo 
    @StartDate = '20130101', 
    @EndDate = '20130107';

/*Wide range, good estimate?*/
EXEC dbo.PostInfo 
    @StartDate = '20130101', 
    @EndDate = '20130601';

/*If we recompile and run in reverse, what happens?*/
EXEC sys.sp_recompile 
    @objname = N'dbo.PostInfo';
