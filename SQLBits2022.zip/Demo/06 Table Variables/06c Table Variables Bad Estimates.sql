﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
DBCC FREEPROCCACHE;
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 150;
SET NOCOUNT ON;
GO 

CREATE INDEX 
    dog 
ON dbo.Posts
    (OwnerUserId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);

CREATE INDEX 
    cat 
ON dbo.Comments
    (UserId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);


/*
███████╗████████╗ █████╗ ████████╗███████╗    ████████╗██╗  ██╗ ██████╗ 
██╔════╝╚══██╔══╝██╔══██╗╚══██╔══╝██╔════╝    ╚══██╔══╝██║  ██║██╔═══██╗
███████╗   ██║   ███████║   ██║   ███████╗       ██║   ███████║██║   ██║
╚════██║   ██║   ██╔══██║   ██║   ╚════██║       ██║   ██╔══██║██║   ██║
███████║   ██║   ██║  ██║   ██║   ███████║       ██║   ██║  ██║╚██████╔╝
╚══════╝   ╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚══════╝       ╚═╝   ╚═╝  ╚═╝ ╚═════╝ 
*/

/*
This is a table variable insert
*/
DECLARE 
    @t table
( 
    id int, 
    INDEX c CLUSTERED (id) 
);

INSERT 
    @t 
( 
    id 
)
SELECT 
    x.id
FROM 
( 
    SELECT 
        22656 /*Jon Skeet, lotsa rows*/
    
    UNION ALL 
    
    SELECT TOP (1000) 
        u.Id /*Buncha scrubs, hardly any rows*/
    FROM dbo.Users AS u
    WHERE u.Reputation = 1
    ORDER BY CreationDate
) AS x (id);


/*
Note that we still get accurate table cardinality, 1001 rows
But no stats information about what's in there
*/
SELECT 
    lmao = COUNT_BIG(*)
FROM @t AS t
JOIN dbo.Posts AS p
    ON p.OwnerUserId = t.id
JOIN dbo.Comments AS c
    ON c.UserId = t.id;
GO

/*
Pls just show the saved plan.
*/













/*

Table variables use secret #temporary objects

They're random, and they get destroyed after the query.

*/
SET STATISTICS IO ON;

DECLARE 
    @t table
( 
    id int, 
    INDEX c CLUSTERED (id) 
);

INSERT @t 
( 
    id 
)
SELECT 
    x.id 
FROM 
( 
    SELECT 
        22656 /*Jon Skeet, lotsa rows*/
    
    UNION ALL 
    
    SELECT TOP (1000) 
        u.Id /*Buncha scrubs, hardly any rows*/
    FROM dbo.Users AS u
    WHERE u.Reputation = 1
    ORDER BY CreationDate
) AS x (id);

SELECT 
    records = COUNT_BIG(*) 
FROM @t AS t 
WHERE t.id > 2147483647;

SET STATISTICS IO OFF;














/*
#temp tables don't have the same issues.

Still.

Please use #temp tables when this matters.
*/
DBCC FREEPROCCACHE;

DROP TABLE IF EXISTS #t;

CREATE TABLE 
    #t 
( 
    id int 
); /*This doesn't even have an index.*/

INSERT 
    #t 
( 
    id 
)
SELECT 
    x.id 
FROM 
( 
    SELECT 
        22656 /*Jon Skeet, lotsa rows*/
    
    UNION ALL 
    
    SELECT TOP (1000) 
        u.Id /*Buncha scrubs, hardly any rows*/
    FROM dbo.Users AS u
    WHERE u.Reputation = 1
    ORDER BY CreationDate
) AS x(id);


SELECT 
    lmao = COUNT_BIG(*)
FROM   #t AS t
JOIN   dbo.Posts AS p
    ON p.OwnerUserId = t.id
JOIN   dbo.Comments AS c
    ON c.UserId = t.id;

SELECT 
    hist.step_number, 
    hist.range_high_key, 
    hist.range_rows, 
    hist.equal_rows, 
    hist.distinct_range_rows, 
    hist.average_range_rows
FROM tempdb.sys.stats AS s
CROSS APPLY tempdb.sys.dm_db_stats_histogram(s.object_id, s.stats_id) AS hist
WHERE OBJECT_NAME(s.object_id, 2) LIKE '#t%';
GO 



/*
Okay, but why?!
*/


DBCC FREEPROCCACHE;

DECLARE 
    @t table
(
    id int, 
    INDEX c CLUSTERED (id)
);
INSERT 
    @t 
( 
    id 
) 
VALUES (22656);

SELECT 
    records = COUNT_BIG(*)
FROM dbo.Posts AS p
JOIN @t AS t
    ON t.id = p.OwnerUserId
OPTION(QUERYTRACEON 3604, QUERYTRACEON 2363);

/*
CStCollJoin(ID=3, CARD=11.9452 x_jtInner)

    CStCollBaseTable(ID=1, CARD=1.71422e+07 TBL: dbo.Posts AS TBL: p)

    CStCollBlackBox(ID=2, CARD=1)
*/

DBCC FREEPROCCACHE;
DROP TABLE IF EXISTS #t;

CREATE TABLE 
    #t 
(
    id int, 
    INDEX c CLUSTERED (id)
);
INSERT 
    #t 
( 
    id 
) 
VALUES (22656);

SELECT 
    records = COUNT_BIG(*)
FROM dbo.Posts AS p
JOIN #t AS t
    ON t.id = p.OwnerUserId
OPTION(QUERYTRACEON 3604, QUERYTRACEON 2363);

/*
CStCollJoin(ID=3, CARD=27901 x_jtInner)

    CStCollBaseTable(ID=1, CARD=1.71422e+07 TBL: dbo.Posts AS TBL: p)

    CStCollBaseTable(ID=2, CARD=1 TBL: #t AS TBL: t)
*/


SELECT 
    hist.step_number, 
    hist.range_high_key, 
    hist.range_rows, 
    hist.equal_rows, 
    hist.distinct_range_rows, 
    hist.average_range_rows
FROM tempdb.sys.stats AS s
    CROSS APPLY tempdb.sys.dm_db_stats_histogram(s.object_id, s.stats_id) AS hist
WHERE OBJECT_NAME(s.object_id, 2) LIKE '#t%';
GO 






/*

Temp table problems?

*/
EXEC dbo.DropIndexes;


CREATE INDEX 
    grmpf 
ON dbo.Posts
    (ParentId, OwnerUserId) 
WITH (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 


CREATE OR ALTER PROCEDURE 
    dbo.TempTableProblems
(
    @ParentId int
)
AS
BEGIN
SET NOCOUNT, XACT_ABORT ON;

    CREATE TABLE 
        #ParentId 
    (
        ParentId int NOT NULL
    );
        
    INSERT 
        #ParentId 
    ( 
        ParentId 
    ) 
    SELECT 
        ParentId = @ParentId;
    
    SELECT TOP (10) 
        u.DisplayName, 
        p.*
    FROM dbo.Posts AS p
    JOIN dbo.Users AS u
        ON p.OwnerUserId = u.Id
    JOIN #ParentId AS pid
        ON p.ParentId = pid.ParentId
    ORDER BY u.Reputation DESC;
    
    DBCC SHOW_STATISTICS(N'tempdb..#ParentId', N'ParentId') 
        WITH STAT_HEADER, HISTOGRAM;

END;
GO 

EXEC dbo.TempTableProblems 
    @ParentId = 184618;

40-ish seconds
EXEC dbo.TempTableProblems 
    @ParentId = 0;

EXEC sys.sp_recompile 
    @objname = N'dbo.TempTableProblems';


/*

#temp table get things like statistics cached, recompile thresholds
can be hit by certain things, like number of row modifications,
ddl, directly updating statistics and recompile hints.

Pablo Blanco:
  * https://www.sql.kiwi/2012/08/temporary-object-caching-explained.html
  * https://www.sql.kiwi/2012/08/temporary-tables-in-stored-procedures.html
  * https://sqlperformance.com/2017/05/sql-performance/sql-server-temporary-object-caching

*/