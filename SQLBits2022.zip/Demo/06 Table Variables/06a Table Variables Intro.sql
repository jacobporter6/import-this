﻿USE StackOverflow2013;
EXEC dbo.DropIndexes;
DBCC FREEPROCCACHE;

CREATE INDEX 
    o 
ON dbo.Posts
    (OwnerUserId) 
WITH
    (MAXDOP = 8, SORT_IN_TEMPDB = ON, DATA_COMPRESSION = PAGE);
GO 


/*
██████╗  █████╗ ███████╗██╗ ██████╗              
██╔══██╗██╔══██╗██╔════╝██║██╔════╝              
██████╔╝███████║███████╗██║██║                   
██╔══██╗██╔══██║╚════██║██║██║                   
██████╔╝██║  ██║███████║██║╚██████╗              
╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝ ╚═════╝              
                                                 
████████╗ █████╗ ██████╗ ██╗     ███████╗███████╗
╚══██╔══╝██╔══██╗██╔══██╗██║     ██╔════╝██╔════╝
   ██║   ███████║██████╔╝██║     █████╗  ███████╗
   ██║   ██╔══██║██╔══██╗██║     ██╔══╝  ╚════██║
   ██║   ██║  ██║██████╔╝███████╗███████╗███████║
   ╚═╝   ╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝╚══════╝
*/

/*

Table variables in < 150 compatibility levels
 * Always a one row estimate
  * Recompiling gives table cardinality
  * Trace flag 2453 kind of helps?

Table variables in >= 150 compatibility levels
 * Table cardinality
 * But gets weird in stored procedures

Always and (maybe?) forever:
 * No column-level distribution statistics
  * Indexes don't help with this
 * No parallelism on modifications
 * Great for high frequency execution, though
  * https://www.erikdarlingdata.com/sql-server/when-should-you-use-table-variables/
  * Like and subscribe!

*/
ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 140;

ALTER DATABASE StackOverflow2013 SET COMPATIBILITY_LEVEL = 150;

DBCC FREEPROCCACHE;

DECLARE 
    @t table
(
    id INT, 
    INDEX c CLUSTERED(id)
);

INSERT 
    @t 
(
    id
)
SELECT 
    p.OwnerUserId
FROM dbo.Posts AS p
WHERE p.OwnerUserId = 0;

SELECT 
    t.id, 
    records = COUNT_BIG(*)
FROM @t AS t
GROUP BY t.id
OPTION (QUERYTRACEON 3604, QUERYTRACEON 2363);

SELECT 
    t.id, 
    records = COUNT_BIG(*)
FROM @t AS t
WHERE t.id = 0
GROUP BY t.id
OPTION (QUERYTRACEON 3604, QUERYTRACEON 2363);

